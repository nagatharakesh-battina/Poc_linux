// Resource-leak tests: file descriptors, threads, zombie processes and heap growth.
// (Valgrind / LeakSanitizer additionally prove that every malloc is freed: make leakcheck / make asan.)
#include "test_util.hpp"
#include <dirent.h>
#include <errno.h>
#include <malloc.h>
#include <sys/wait.h>
#include <unistd.h>

namespace {

int count_dir(const char *path) {
    int n = 0;
    DIR *d = opendir(path);
    if (!d) return -1;
    while (readdir(d)) n++;
    closedir(d);
    return n;
}
int fds_now()     { return count_dir("/proc/self/fd"); }
int threads_now() { return count_dir("/proc/self/task"); }

class LeakTest : public ::testing::Test {
protected:
    TempDir dir;
    std::string state() const { return dir.file("state"); }
};

TEST_F(LeakTest, ShellLifecycleDoesNotLeakDescriptors) {
    int before = fds_now();
    for (int i = 0; i < 60; i++) {
        Shell sh;
        ASSERT_EQ(shell_init(&sh, state().c_str(), 0), 0);
        shell_run_line(&sh, "echo x | cat > /dev/null");
        shell_destroy(&sh);
    }
    EXPECT_EQ(fds_now(), before);
}

TEST_F(LeakTest, ErrorPathsInPipelinesDoNotLeakDescriptors) {
    Shell sh;
    ASSERT_EQ(shell_init(&sh, state().c_str(), 0), 0);
    int before = fds_now();
    for (int i = 0; i < 40; i++) {
        shell_run_line(&sh, "nosuchcmd_zz | cat");              // exec failure in first stage
        shell_run_line(&sh, "echo a | nosuchcmd_zz | wc -l");   // exec failure in middle stage
        shell_run_line(&sh, "cat < /no/such/file | wc -l");     // redirect failure
        shell_run_line(&sh, "echo a > /no/such/dir/f | cat");   // output redirect failure
        shell_run_line(&sh, "echo bad |");                      // syntax error
    }
    EXPECT_EQ(fds_now(), before);
    shell_destroy(&sh);
}

TEST_F(LeakTest, BuiltinRedirectionDoesNotLeakDescriptors) {
    Shell sh;
    ASSERT_EQ(shell_init(&sh, state().c_str(), 0), 0);
    int before = fds_now();
    for (int i = 0; i < 100; i++) {
        shell_run_line(&sh, ("pwd > " + dir.file("p.txt")).c_str());
        shell_run_line(&sh, "echo hi > /no/such/dir/x");
        shell_run_line(&sh, "cd < /no/such/file");
    }
    EXPECT_EQ(fds_now(), before);
    shell_destroy(&sh);
}

TEST_F(LeakTest, NoZombieProcessesAfterBackgroundJobs) {
    Shell sh;
    ASSERT_EQ(shell_init(&sh, state().c_str(), 0), 0);
    for (int i = 0; i < 20; i++) shell_run_line(&sh, "true &");
    for (int i = 0; i < 20; i++) shell_run_line(&sh, "echo x | cat > /dev/null &");
    for (int i = 0; i < 300 && jobs_count(&sh.jobs) > 0; i++) {
        jobs_update(&sh.jobs);
        jobs_notify_done(&sh.jobs, nullptr);
        usleep(10000);
    }
    EXPECT_EQ(jobs_count(&sh.jobs), 0);
    errno = 0;
    EXPECT_EQ(waitpid(-1, nullptr, WNOHANG), -1);   // no child left, not even a zombie
    EXPECT_EQ(errno, ECHILD);
    shell_destroy(&sh);
}

TEST_F(LeakTest, MonitorStartStopDoesNotLeakThreads) {
    Logger lg;
    ASSERT_EQ(logger_open(&lg, dir.file("a.log").c_str()), 0);
    int before = threads_now();
    for (int i = 0; i < 25; i++) {
        Monitor m;
        monitor_init(&m, &lg);
        ASSERT_EQ(monitor_start(&m, 10), 0);
        usleep(15000);
        monitor_destroy(&m);
    }
    EXPECT_EQ(threads_now(), before);
    logger_close(&lg);
}

static void noop(void *) {}

TEST_F(LeakTest, ThreadPoolCreateDestroyDoesNotLeakThreads) {
    int before = threads_now();
    for (int i = 0; i < 25; i++) {
        ThreadPool *tp = tp_create(4);
        ASSERT_NE(tp, nullptr);
        for (int k = 0; k < 20; k++) tp_submit(tp, noop, nullptr);
        tp_wait(tp);
        tp_destroy(tp);
    }
    EXPECT_EQ(threads_now(), before);
}

TEST_F(LeakTest, ThreadPoolFreesTasksThatNeverRan) {
    // valgrind/ASan verify the heap; here we only make sure destroy with queued work is safe
    ThreadPool *tp = tp_create(1);
    static pthread_mutex_t gate = PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&gate);
    tp_submit(tp, [](void *) { pthread_mutex_lock(&gate); pthread_mutex_unlock(&gate); }, nullptr);
    for (int i = 0; i < 50; i++) tp_submit(tp, noop, nullptr);
    pthread_mutex_unlock(&gate);
    tp_destroy(tp);
    SUCCEED();
}

#if defined(__GLIBC__) && defined(__GLIBC_PREREQ)
#if __GLIBC_PREREQ(2, 33)
// Heap-growth test: repeated parse / history / shell usage must not grow the heap.
static size_t heap_in_use() {
    malloc_trim(0);
    return mallinfo2().uordblks;
}

TEST_F(LeakTest, ParserDoesNotGrowHeap) {
    Pipeline p; char err[128];
    for (int i = 0; i < 200; i++) {                       // warm-up
        parse_line("cat a | grep \"x y\" > out &", &p, err, sizeof err);
        pipeline_free(&p);
    }
    size_t before = heap_in_use();
    for (int i = 0; i < 20000; i++) {
        parse_line("cat a < in | grep \"x y\" | sort >> out &", &p, err, sizeof err);
        pipeline_free(&p);
        parse_line("echo 'unterminated", &p, err, sizeof err);      // error path
        parse_line("a | | b", &p, err, sizeof err);                 // error path
    }
    EXPECT_LE(heap_in_use(), before + 4096);
}

TEST_F(LeakTest, HistoryDoesNotGrowHeapBeyondItsLimit) {
    History h;
    history_init(&h, 50);
    for (int i = 0; i < 200; i++) history_add(&h, ("warm" + std::to_string(i)).c_str());
    size_t before = heap_in_use();
    for (int i = 0; i < 20000; i++) {
        history_add(&h, ("command number " + std::to_string(i)).c_str());
        char *out = nullptr;
        if (history_expand(&h, "!!", &out) == 1) free(out);
    }
    EXPECT_LE(heap_in_use(), before + 8192);
    EXPECT_EQ(h.count, 50);
    history_destroy(&h);
}

TEST_F(LeakTest, ShellSessionDoesNotGrowHeap) {
    Shell sh;
    ASSERT_EQ(shell_init(&sh, state().c_str(), 0), 0);
    for (int i = 0; i < 100; i++) shell_run_line(&sh, "echo warm | cat > /dev/null");
    size_t before = heap_in_use();
    for (int i = 0; i < 400; i++) {
        shell_run_line(&sh, "echo hello | tr a-z A-Z > /dev/null");
        shell_run_line(&sh, "true && false || echo x > /dev/null");
        shell_run_line(&sh, "sleep 0 &");
        jobs_update(&sh.jobs);
        jobs_notify_done(&sh.jobs, nullptr);
    }
    for (int i = 0; i < 200 && jobs_count(&sh.jobs) > 0; i++) {
        jobs_update(&sh.jobs);
        jobs_notify_done(&sh.jobs, nullptr);
        usleep(5000);
    }
    EXPECT_LE(heap_in_use(), before + 65536);       // history is capped, jobs are pruned
    shell_destroy(&sh);
}
#endif
#endif

TEST_F(LeakTest, LoggerFlushMakesRecordsVisible) {
    Logger lg;
    ASSERT_EQ(logger_open(&lg, dir.file("f.log").c_str()), 0);
    logger_write(&lg, "one");
    logger_flush(&lg);
    EXPECT_EQ(read_file(dir.file("f.log")), "one\n");
    logger_close(&lg);
    logger_flush(&lg);          // closed logger: must be a harmless no-op
    logger_flush(nullptr);
}

TEST_F(LeakTest, StrayChildrenAreReapedWithoutTouchingJobTable) {
    JobTable t;
    jobs_init(&t);
    pid_t pid = fork();
    if (pid == 0) _exit(0);
    ASSERT_GT(pid, 0);
    for (int i = 0; i < 200; i++) { jobs_update(&t); usleep(5000); if (waitpid(pid, nullptr, WNOHANG) == -1) break; }
    EXPECT_EQ(jobs_count(&t), 0);
    EXPECT_EQ(jobs_find_by_pid(&t, pid), nullptr);
    jobs_destroy(&t);
}

TEST_F(LeakTest, BuiltinTableIsUsedByLookup) {
    size_t n = 0;
    const Builtin *t = builtin_table(&n);
    ASSERT_NE(t, nullptr);
    for (size_t i = 0; i < n; i++) EXPECT_TRUE(builtin_is(t[i].name));
}

} // namespace
