#include "test_util.hpp"

namespace {

class HistoryTest : public ::testing::Test {
protected:
    History h;
    void SetUp() override { history_init(&h, 5); }
    void TearDown() override { history_destroy(&h); }
};

TEST_F(HistoryTest, AddAndGet) {
    EXPECT_EQ(history_add(&h, "ls"), 1);
    EXPECT_EQ(history_add(&h, "pwd"), 1);
    EXPECT_EQ(h.count, 2);
    EXPECT_STREQ(history_get(&h, 1), "ls");
    EXPECT_STREQ(history_get(&h, 2), "pwd");
    EXPECT_STREQ(history_last(&h), "pwd");
    EXPECT_EQ(history_get(&h, 99), nullptr);
}

TEST_F(HistoryTest, IgnoresBlankAndConsecutiveDuplicates) {
    EXPECT_EQ(history_add(&h, ""), 0);
    EXPECT_EQ(history_add(&h, "   \t"), 0);
    EXPECT_EQ(history_add(&h, "ls"), 1);
    EXPECT_EQ(history_add(&h, "ls"), 0);
    EXPECT_EQ(history_add(&h, "pwd"), 1);
    EXPECT_EQ(history_add(&h, "ls"), 1);
    EXPECT_EQ(h.count, 3);
}

TEST_F(HistoryTest, OldestEntriesAreDroppedAtCapacity) {
    for (int i = 1; i <= 8; i++) history_add(&h, ("cmd" + std::to_string(i)).c_str());
    EXPECT_EQ(h.count, 5);
    EXPECT_EQ(history_get(&h, 1), nullptr);
    EXPECT_STREQ(history_get(&h, 4), "cmd4");
    EXPECT_STREQ(history_last(&h), "cmd8");
    EXPECT_EQ(h.head->number, 4);
}

TEST_F(HistoryTest, ClearEmptiesList) {
    history_add(&h, "a");
    history_clear(&h);
    EXPECT_EQ(h.count, 0);
    EXPECT_EQ(history_last(&h), nullptr);
    EXPECT_EQ(history_add(&h, "b"), 1);
}

TEST_F(HistoryTest, ExpandBangBang) {
    history_add(&h, "echo hello");
    char *out = nullptr;
    ASSERT_EQ(history_expand(&h, "!!", &out), 1);
    EXPECT_STREQ(out, "echo hello");
    free(out);
    ASSERT_EQ(history_expand(&h, "!! | wc -c", &out), 1);
    EXPECT_STREQ(out, "echo hello | wc -c");
    free(out);
}

TEST_F(HistoryTest, ExpandByNumberAndPrefix) {
    history_add(&h, "ls -l");
    history_add(&h, "grep foo file");
    history_add(&h, "pwd");
    char *out = nullptr;
    ASSERT_EQ(history_expand(&h, "!2", &out), 1);
    EXPECT_STREQ(out, "grep foo file");
    free(out);
    ASSERT_EQ(history_expand(&h, "!ls", &out), 1);
    EXPECT_STREQ(out, "ls -l");
    free(out);
}

TEST_F(HistoryTest, ExpandNotFoundAndNotAnExpansion) {
    char *out = nullptr;
    EXPECT_EQ(history_expand(&h, "!!", &out), -1);          // empty history
    history_add(&h, "ls");
    EXPECT_EQ(history_expand(&h, "!zzz", &out), -1);
    EXPECT_EQ(history_expand(&h, "!99", &out), -1);
    EXPECT_EQ(history_expand(&h, "echo hi!", &out), 0);
    EXPECT_EQ(history_expand(&h, "! ls", &out), 0);
    EXPECT_EQ(history_expand(&h, "!", &out), 0);
    EXPECT_EQ(out, nullptr);
}

TEST_F(HistoryTest, PrintLastN) {
    for (int i = 1; i <= 4; i++) history_add(&h, ("c" + std::to_string(i)).c_str());
    char *buf = nullptr; size_t len = 0;
    FILE *f = open_memstream(&buf, &len);
    history_print(&h, 2, f);
    fclose(f);
    std::string s(buf);
    free(buf);
    EXPECT_EQ(count_lines(s), 2);
    EXPECT_NE(s.find("c3"), std::string::npos);
    EXPECT_NE(s.find("c4"), std::string::npos);
    EXPECT_EQ(s.find("c2"), std::string::npos);
}

TEST_F(HistoryTest, SaveAndLoadRoundTrip) {
    TempDir dir;
    history_add(&h, "ls");
    history_add(&h, "echo \"a b\" | wc");
    ASSERT_EQ(history_save(&h, dir.file("hist").c_str()), 0);

    History h2;
    history_init(&h2, 10);
    ASSERT_EQ(history_load(&h2, dir.file("hist").c_str()), 0);
    EXPECT_EQ(h2.count, 2);
    EXPECT_STREQ(history_get(&h2, 2), "echo \"a b\" | wc");
    history_destroy(&h2);
}

TEST_F(HistoryTest, LoadMissingFileFails) {
    EXPECT_EQ(history_load(&h, "/nonexistent/path/history"), -1);
}

} // namespace
