// Utilities + multithreading tests (thread pool, logger, log analyzer, monitor)
#include "test_util.hpp"
#include <atomic>
#include <thread>
#include <vector>
#include <unistd.h>

namespace {

// ---------------------------------------------------------------- utils
TEST(Utils, StrBufGrowsAndTakes) {
    StrBuf sb;
    sb_init(&sb);
    for (int i = 0; i < 1000; i++) sb_putc(&sb, 'a');
    sb_puts(&sb, "-end");
    EXPECT_EQ(sb.len, 1004u);
    char *s = sb_take(&sb);
    EXPECT_EQ(strlen(s), 1004u);
    EXPECT_STREQ(s + 1000, "-end");
    free(s);
}

TEST(Utils, StrBufEmptyTakeIsValidString) {
    StrBuf sb;
    sb_init(&sb);
    char *s = sb_take(&sb);
    ASSERT_NE(s, nullptr);
    EXPECT_STREQ(s, "");
    free(s);
}

TEST(Utils, Trim) {
    char a[] = "  hi there \n";
    EXPECT_STREQ(str_trim(a), "hi there");
    char b[] = "   ";
    EXPECT_STREQ(str_trim(b), "");
    char c[] = "x";
    EXPECT_STREQ(str_trim(c), "x");
}

TEST(Utils, StartsEndsWith) {
    EXPECT_TRUE(str_starts_with("minishell", "mini"));
    EXPECT_FALSE(str_starts_with("mini", "minishell"));
    EXPECT_TRUE(str_ends_with("file.tmp", ".tmp"));
    EXPECT_FALSE(str_ends_with("tmp", "file.tmp"));
}

TEST(Utils, ParseLong) {
    long v = 0;
    EXPECT_EQ(parse_long("123", &v), 0);
    EXPECT_EQ(v, 123);
    EXPECT_EQ(parse_long("-7", &v), 0);
    EXPECT_EQ(v, -7);
    EXPECT_EQ(parse_long("12x", &v), -1);
    EXPECT_EQ(parse_long("", &v), -1);
    EXPECT_EQ(parse_long(nullptr, &v), -1);
    EXPECT_EQ(parse_long("99999999999999999999999", &v), -1);
}

// ------------------------------------------------------------ thread pool
struct Counter {
    pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
    long value = 0;
};
void bump(void *arg) {
    Counter *c = (Counter *)arg;
    pthread_mutex_lock(&c->lock);
    c->value++;
    pthread_mutex_unlock(&c->lock);
}

TEST(ThreadPool, RunsAllTasks) {
    ThreadPool *tp = tp_create(4);
    ASSERT_NE(tp, nullptr);
    Counter c;
    for (int i = 0; i < 2000; i++) ASSERT_EQ(tp_submit(tp, bump, &c), 0);
    tp_wait(tp);
    EXPECT_EQ(c.value, 2000);
    tp_destroy(tp);
}

TEST(ThreadPool, WaitCanBeReused) {
    ThreadPool *tp = tp_create(3);
    Counter c;
    for (int round = 1; round <= 3; round++) {
        for (int i = 0; i < 100; i++) tp_submit(tp, bump, &c);
        tp_wait(tp);
        EXPECT_EQ(c.value, 100 * round);
    }
    tp_destroy(tp);
}

TEST(ThreadPool, SingleThreadPreservesOrder) {
    ThreadPool *tp = tp_create(1);
    static std::vector<int> order;
    order.clear();
    static int ids[50];
    for (int i = 0; i < 50; i++) {
        ids[i] = i;
        tp_submit(tp, [](void *a) { order.push_back(*(int *)a); }, &ids[i]);
    }
    tp_wait(tp);
    ASSERT_EQ(order.size(), 50u);
    for (int i = 0; i < 50; i++) EXPECT_EQ(order[i], i);
    tp_destroy(tp);
}

TEST(ThreadPool, TasksActuallyRunInParallel) {
    ThreadPool *tp = tp_create(4);
    struct Gate { std::atomic<int> arrived{0}; } gate;
    // 4 tasks each wait until all 4 have started: only possible with real parallelism
    for (int i = 0; i < 4; i++) {
        tp_submit(tp, [](void *a) {
            Gate *g = (Gate *)a;
            g->arrived++;
            for (int spin = 0; spin < 2000 && g->arrived < 4; spin++) usleep(1000);
        }, &gate);
    }
    tp_wait(tp);
    EXPECT_EQ(gate.arrived.load(), 4);
    tp_destroy(tp);
}

TEST(ThreadPool, DestroyWithoutTasksAndInvalidArgs) {
    ThreadPool *tp = tp_create(0);            // clamped to 1 thread
    ASSERT_NE(tp, nullptr);
    EXPECT_EQ(tp_submit(tp, nullptr, nullptr), -1);
    tp_destroy(tp);
    tp_destroy(nullptr);                      // must be a no-op
}

// ------------------------------------------------------------------ logger
TEST(Logger, ConcurrentWritersProduceIntactLines) {
    TempDir dir;
    Logger lg;
    ASSERT_EQ(logger_open(&lg, dir.file("t.log").c_str()), 0);
    const int kThreads = 8, kLines = 250;
    std::vector<std::thread> th;
    for (int t = 0; t < kThreads; t++)
        th.emplace_back([&lg, t] {
            for (int i = 0; i < kLines; i++)
                logger_write(&lg, "thread=%d line=%d payload=0123456789abcdef", t, i);
        });
    for (auto &x : th) x.join();
    logger_close(&lg);

    std::istringstream in(read_file(dir.file("t.log")));
    std::string line;
    int n = 0;
    while (std::getline(in, line)) {
        n++;
        EXPECT_NE(line.find("payload=0123456789abcdef"), std::string::npos) << line;
        EXPECT_EQ(line.rfind("thread=", 0), 0u) << line;
    }
    EXPECT_EQ(n, kThreads * kLines);
}

TEST(Logger, OpenFailureAndNullSafety) {
    Logger lg;
    EXPECT_EQ(logger_open(&lg, "/nonexistent_dir/x.log"), -1);
    logger_write(&lg, "ignored %d", 1);      // fp == NULL: must not crash
    logger_close(&lg);
}

TEST(Logger, TimestampFormat) {
    char ts[32];
    log_timestamp(ts, sizeof ts);
    ASSERT_EQ(strlen(ts), 19u);
    EXPECT_EQ(ts[4], '-');
    EXPECT_EQ(ts[10], ' ');
    EXPECT_EQ(ts[13], ':');
}

// ------------------------------------------------------------ log analyzer
TEST(LogAnalyzer, CountsLevelsCaseInsensitive) {
    TempDir dir;
    write_file(dir.file("a.log"),
               "INFO start\nerror one\nERROR two\nWarning x\nWARN y\nplain line\nNeedle here\n");
    LogStats st;
    ASSERT_EQ(analyze_file(dir.file("a.log").c_str(), "Needle", &st), 0);
    EXPECT_TRUE(st.ok);
    EXPECT_EQ(st.lines, 7);
    EXPECT_EQ(st.errors, 2);
    EXPECT_EQ(st.warnings, 2);
    EXPECT_EQ(st.infos, 1);
    EXPECT_EQ(st.matches, 1);
}

TEST(LogAnalyzer, MissingFileReportsFailure) {
    LogStats st;
    EXPECT_EQ(analyze_file("/nonexistent/file.log", nullptr, &st), -1);
    EXPECT_FALSE(st.ok);
}

TEST(LogAnalyzer, EmptyFileAndNoTrailingNewline) {
    TempDir dir;
    write_file(dir.file("e.log"), "");
    write_file(dir.file("n.log"), "ERROR last line without newline");
    LogStats a, b;
    ASSERT_EQ(analyze_file(dir.file("e.log").c_str(), nullptr, &a), 0);
    ASSERT_EQ(analyze_file(dir.file("n.log").c_str(), nullptr, &b), 0);
    EXPECT_EQ(a.lines, 0);
    EXPECT_EQ(b.lines, 1);
    EXPECT_EQ(b.errors, 1);
}

TEST(LogAnalyzer, ParallelMatchesSequential) {
    TempDir dir;
    const int kFiles = 24;
    std::vector<std::string> names;
    for (int i = 0; i < kFiles; i++) {
        std::string body;
        for (int k = 0; k < 200 + i; k++) {
            if (k % 7 == 0) body += "ERROR failure " + std::to_string(k) + "\n";
            else if (k % 5 == 0) body += "WARN slow " + std::to_string(k) + "\n";
            else body += "INFO ok " + std::to_string(k) + "\n";
        }
        names.push_back(dir.file("f" + std::to_string(i) + ".log"));
        write_file(names.back(), body);
    }
    std::vector<char *> paths;
    for (auto &n : names) paths.push_back((char *)n.c_str());

    std::vector<LogStats> par(kFiles), seq(kFiles);
    ASSERT_EQ(analyze_files_parallel(paths.data(), kFiles, "failure", 6, par.data()), 0);
    for (int i = 0; i < kFiles; i++) analyze_file(paths[i], "failure", &seq[i]);

    for (int i = 0; i < kFiles; i++) {
        EXPECT_EQ(par[i].lines, seq[i].lines) << i;
        EXPECT_EQ(par[i].errors, seq[i].errors) << i;
        EXPECT_EQ(par[i].warnings, seq[i].warnings) << i;
        EXPECT_EQ(par[i].infos, seq[i].infos) << i;
        EXPECT_EQ(par[i].matches, seq[i].matches) << i;
        EXPECT_TRUE(par[i].ok);
    }
    LogStats total;
    log_stats_total(par.data(), kFiles, &total);
    long errs = 0;
    for (auto &s : seq) errs += s.errors;
    EXPECT_EQ(total.errors, errs);
}

TEST(LogAnalyzer, ParallelHandlesMixOfGoodAndBadFiles) {
    TempDir dir;
    write_file(dir.file("ok.log"), "ERROR x\n");
    std::string good = dir.file("ok.log");
    char *paths[] = {(char *)good.c_str(), (char *)"/no/such/file", (char *)good.c_str()};
    LogStats res[3];
    ASSERT_EQ(analyze_files_parallel(paths, 3, nullptr, 8, res), 0);
    EXPECT_TRUE(res[0].ok);
    EXPECT_FALSE(res[1].ok);
    EXPECT_TRUE(res[2].ok);
}

TEST(LogAnalyzer, PrintContainsTotals) {
    LogStats r[2];
    memset(r, 0, sizeof r);
    snprintf(r[0].path, sizeof r[0].path, "a.log"); r[0].ok = 1; r[0].lines = 10; r[0].errors = 3;
    snprintf(r[1].path, sizeof r[1].path, "b.log"); r[1].ok = 1; r[1].lines = 5;  r[1].errors = 1;
    char *buf = nullptr; size_t len = 0;
    FILE *f = open_memstream(&buf, &len);
    log_stats_print(r, 2, nullptr, f);
    fclose(f);
    std::string s(buf);
    free(buf);
    EXPECT_NE(s.find("TOTAL"), std::string::npos);
    EXPECT_NE(s.find("15"), std::string::npos);
}

// ----------------------------------------------------------------- monitor
TEST(MonitorParsers, Loadavg) {
    double v[3];
    ASSERT_EQ(parse_loadavg("0.52 0.41 0.30 1/234 5678\n", v), 0);
    EXPECT_DOUBLE_EQ(v[0], 0.52);
    EXPECT_DOUBLE_EQ(v[1], 0.41);
    EXPECT_DOUBLE_EQ(v[2], 0.30);
    EXPECT_EQ(parse_loadavg("garbage", v), -1);
    EXPECT_EQ(parse_loadavg("", v), -1);
}

TEST(MonitorParsers, Meminfo) {
    unsigned long total = 0, avail = 0;
    const char *text = "MemTotal:       16000000 kB\nMemFree:         1000000 kB\n"
                       "MemAvailable:    8000000 kB\nBuffers: 1 kB\n";
    ASSERT_EQ(parse_meminfo(text, &total, &avail), 0);
    EXPECT_EQ(total, 16000000ul);
    EXPECT_EQ(avail, 8000000ul);
    EXPECT_EQ(parse_meminfo("MemTotal: 5 kB\n", &total, &avail), -1);
    EXPECT_EQ(parse_meminfo("", &total, &avail), -1);
}

TEST(MonitorMetrics, CollectGivesSaneValues) {
    SystemMetrics m;
    ASSERT_EQ(metrics_collect(&m), 0);
    EXPECT_GE(m.ncpu, 1);
    EXPECT_GT(m.mem_total_kb, 0ul);
    EXPECT_GE(m.mem_used_pct, 0.0);
    EXPECT_LE(m.mem_used_pct, 100.0);
    EXPECT_GE(m.disk_used_pct, 0.0);
    EXPECT_LE(m.disk_used_pct, 100.0);
    EXPECT_GT(m.uptime_sec, 0.0);
}

TEST(MonitorMetrics, AlertThresholds) {
    SystemMetrics m;
    memset(&m, 0, sizeof m);
    m.ncpu = 4;
    char buf[256];
    EXPECT_EQ(metrics_check_alerts(&m, buf, sizeof buf), 0);
    EXPECT_STREQ(buf, "");

    m.load1 = 9.5; m.mem_used_pct = 95; m.disk_used_pct = 97;
    EXPECT_EQ(metrics_check_alerts(&m, buf, sizeof buf), 3);
    EXPECT_NE(strstr(buf, "load"), nullptr);
    EXPECT_NE(strstr(buf, "memory"), nullptr);
    EXPECT_NE(strstr(buf, "disk"), nullptr);

    m.load1 = 3.9; m.mem_used_pct = 90; m.disk_used_pct = 89.9;   // exactly at / below limits
    EXPECT_EQ(metrics_check_alerts(&m, buf, sizeof buf), 0);
}

TEST(MonitorThread, SamplesPeriodicallyAndStopsCleanly) {
    TempDir dir;
    Logger lg;
    ASSERT_EQ(logger_open(&lg, dir.file("alerts.log").c_str()), 0);
    Monitor mon;
    monitor_init(&mon, &lg);

    SystemMetrics m;
    EXPECT_EQ(monitor_latest(&mon, &m), -1);        // nothing sampled yet
    EXPECT_FALSE(monitor_is_running(&mon));

    ASSERT_EQ(monitor_start(&mon, 30), 0);
    EXPECT_EQ(monitor_start(&mon, 30), -1);          // already running
    EXPECT_TRUE(monitor_is_running(&mon));

    for (int i = 0; i < 300 && monitor_sample_count(&mon) < 3; i++) usleep(10000);
    EXPECT_GE(monitor_sample_count(&mon), 3ul);
    ASSERT_EQ(monitor_latest(&mon, &m), 0);
    EXPECT_GE(m.ncpu, 1);

    monitor_stop(&mon);
    EXPECT_FALSE(monitor_is_running(&mon));
    unsigned long after = monitor_sample_count(&mon);
    usleep(120000);
    EXPECT_EQ(monitor_sample_count(&mon), after);    // really stopped
    monitor_stop(&mon);                              // second stop is harmless

    ASSERT_EQ(monitor_start(&mon, 30), 0);           // can be restarted
    monitor_destroy(&mon);                           // destroy stops the thread
    logger_close(&lg);
}

TEST(MonitorThread, ReadersAndStopRaceFree) {
    Monitor mon;
    monitor_init(&mon, nullptr);
    ASSERT_EQ(monitor_start(&mon, 5), 0);
    std::vector<std::thread> readers;
    std::atomic<bool> go{true};
    for (int i = 0; i < 4; i++)
        readers.emplace_back([&] {
            SystemMetrics m;
            while (go) { monitor_latest(&mon, &m); monitor_sample_count(&mon); }
        });
    usleep(100000);
    go = false;
    for (auto &r : readers) r.join();
    monitor_destroy(&mon);
}

} // namespace
