// Shared helpers for the GoogleTest suite
#pragma once
#include <gtest/gtest.h>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <unistd.h>
#include <sys/stat.h>

extern "C" {
#include "audit.h"
#include "builtins.h"
#include "history.h"
#include "jobs.h"
#include "loganalyzer.h"
#include "logger.h"
#include "maintenance.h"
#include "monitor.h"
#include "parser.h"
#include "services.h"
#include "shell.h"
#include "threadpool.h"
#include "utils.h"
}

// Creates a private temp directory, removed (recursively) on destruction.
class TempDir {
public:
    TempDir() {
        char tmpl[] = "/tmp/minishell_test_XXXXXX";
        char *p = mkdtemp(tmpl);
        path_ = p ? p : "/tmp";
    }
    ~TempDir() {
        std::string cmd = "rm -rf '" + path_ + "'";
        int rc = system(cmd.c_str());
        (void)rc;
    }
    const std::string &path() const { return path_; }
    std::string file(const std::string &name) const { return path_ + "/" + name; }
private:
    std::string path_;
};

inline void write_file(const std::string &path, const std::string &content) {
    std::ofstream f(path, std::ios::binary);
    f << content;
}

inline std::string read_file(const std::string &path) {
    std::ifstream f(path, std::ios::binary);
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

inline bool file_exists(const std::string &path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}

inline int count_lines(const std::string &s) {
    int n = 0;
    for (char c : s) if (c == '\n') n++;
    return n;
}

inline int open_fd_count() {
    int n = 0;
    std::string cmd;
    FILE *p = popen("ls /proc/self/fd | wc -l", "r");
    if (p) { if (fscanf(p, "%d", &n) != 1) n = -1; pclose(p); }
    return n;
}
