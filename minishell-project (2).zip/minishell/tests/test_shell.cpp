// End-to-end tests: real fork/exec/pipe/dup2 through shell_run_line()
#include "test_util.hpp"
#include <fcntl.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <unistd.h>
#include <limits.h>

namespace {

class ShellTest : public ::testing::Test {
protected:
    TempDir dir;
    Shell sh;
    char orig_cwd[PATH_MAX];

    void SetUp() override {
        ASSERT_NE(getcwd(orig_cwd, sizeof orig_cwd), nullptr);
        ASSERT_EQ(shell_init(&sh, dir.file("state").c_str(), 0), 0);
    }
    void TearDown() override {
        shell_destroy(&sh);
        ASSERT_EQ(chdir(orig_cwd), 0);
    }
    int run(const std::string &line) { return shell_run_line(&sh, line.c_str()); }

    // Runs a command line while process-level stdout is captured into a file.
    std::string out_of(const std::string &cmd) {
        std::string f = dir.file("capture.txt");
        fflush(stdout);
        int saved = dup(STDOUT_FILENO);
        int fd = open(f.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
        dup2(fd, STDOUT_FILENO);
        close(fd);
        run(cmd);
        fflush(stdout);
        dup2(saved, STDOUT_FILENO);
        close(saved);
        return read_file(f);
    }
    void wait_job_done(int id, int ms = 3000) {
        for (int i = 0; i < ms / 10; i++) {
            jobs_update(&sh.jobs);
            Job *j = jobs_find_by_id(&sh.jobs, id);
            if (!j || j->state == JOB_DONE) return;
            usleep(10000);
        }
    }
};

// ---------------------------------------------------------- Level 1: core
TEST_F(ShellTest, ExternalCommandRuns) {
    EXPECT_EQ(out_of("echo hello world"), "hello world\n");
    EXPECT_EQ(sh.last_status, 0);
}

TEST_F(ShellTest, CommandNotFoundReturns127) {
    EXPECT_EQ(run("definitely_not_a_command_xyz"), 127);
}

TEST_F(ShellTest, NonExecutableFileReturns126) {
    write_file(dir.file("script.sh"), "#!/bin/sh\necho hi\n");   // no exec bit
    EXPECT_EQ(run("'" + dir.file("script.sh") + "'"), 126);
}

TEST_F(ShellTest, ExitStatusPropagation) {
    EXPECT_EQ(run("true"), 0);
    EXPECT_EQ(run("false"), 1);
    EXPECT_EQ(run("sh -c 'exit 42'"), 42);
}

TEST_F(ShellTest, DollarQuestionExpansion) {
    run("sh -c 'exit 7'");
    EXPECT_EQ(out_of("echo $?"), "7\n");
}

TEST_F(ShellTest, SyntaxErrorGivesStatus2) {
    EXPECT_EQ(run("echo 'unterminated"), 2);
    EXPECT_EQ(run("ls |"), 2);
}

TEST_F(ShellTest, BlankAndCommentLinesKeepStatus) {
    run("false");
    EXPECT_EQ(run("   "), 1);
    EXPECT_EQ(run("# comment"), 1);
}

TEST_F(ShellTest, CdAndPwd) {
    ASSERT_EQ(run("cd '" + dir.path() + "'"), 0);
    char cwd[PATH_MAX];
    ASSERT_NE(getcwd(cwd, sizeof cwd), nullptr);
    char *real = realpath(dir.path().c_str(), nullptr);
    EXPECT_STREQ(cwd, real);
    free(real);
    EXPECT_EQ(out_of("pwd"), std::string(cwd) + "\n");
}

TEST_F(ShellTest, CdFailureAndCdDash) {
    EXPECT_EQ(run("cd /no/such/dir"), 1);
    EXPECT_EQ(run("cd a b"), 1);
    run("cd /");
    run("cd '" + dir.path() + "'");
    run("cd -");
    char cwd[PATH_MAX];
    ASSERT_NE(getcwd(cwd, sizeof cwd), nullptr);
    EXPECT_STREQ(cwd, "/");
}

TEST_F(ShellTest, ExportAndExpansion) {
    run("export MS_INTEG=hello123");
    EXPECT_EQ(out_of("echo $MS_INTEG"), "hello123\n");
    EXPECT_EQ(out_of("echo \"[$MS_INTEG]\""), "[hello123]\n");
    EXPECT_EQ(out_of("echo '$MS_INTEG'"), "$MS_INTEG\n");
    run("unset MS_INTEG");
    EXPECT_EQ(out_of("echo [$MS_INTEG]"), "[]\n");
}

TEST_F(ShellTest, ExportVisibleToChildren) {
    run("export MS_CHILD=fromparent");
    EXPECT_EQ(out_of("sh -c 'echo $MS_CHILD'"), "fromparent\n");
    unsetenv("MS_CHILD");
}

TEST_F(ShellTest, ExitBuiltinStopsShell) {
    EXPECT_TRUE(sh.running);
    run("exit 3");
    EXPECT_FALSE(sh.running);
    EXPECT_EQ(sh.exit_code, 3);
}

TEST_F(ShellTest, ExitWithBadArgument) {
    run("exit abc");
    EXPECT_EQ(sh.exit_code, 2);
}

TEST_F(ShellTest, EchoNoNewline) {
    EXPECT_EQ(out_of("echo -n abc"), "abc");
}

TEST_F(ShellTest, HelpListsInfrastructureCommands) {
    std::string h = out_of("help");
    for (const char *cmd : {"loganalyze", "monitor", "services", "audit", "cleanup", "sysinfo", "jobs"})
        EXPECT_NE(h.find(cmd), std::string::npos) << cmd;
    EXPECT_NE(out_of("help cd").find("usage: cd"), std::string::npos);
    EXPECT_EQ(run("help nosuchbuiltin"), 1);
}

// --------------------------------------------------------- sequencing ; && ||
TEST_F(ShellTest, SemicolonRunsBoth) {
    EXPECT_EQ(out_of("echo a; echo b"), "a\nb\n");
}

TEST_F(ShellTest, AndOrShortCircuit) {
    EXPECT_EQ(out_of("true && echo yes"), "yes\n");
    EXPECT_EQ(out_of("false && echo no"), "");
    EXPECT_EQ(out_of("false || echo recovered"), "recovered\n");
    EXPECT_EQ(out_of("true || echo no"), "");
}

TEST_F(ShellTest, SeparatorsInsideQuotesAreLiteral) {
    EXPECT_EQ(out_of("echo \"a;b && c || d\""), "a;b && c || d\n");
    EXPECT_EQ(out_of("echo 'x;y'"), "x;y\n");
}

TEST_F(ShellTest, StatusExpansionInsideSequence) {
    EXPECT_EQ(out_of("false; echo $?"), "1\n");
}

// -------------------------------------------------- Level 3: redirection
TEST_F(ShellTest, OutputRedirectTruncates) {
    std::string f = dir.file("o.txt");
    run("echo first > '" + f + "'");
    run("echo second > '" + f + "'");
    EXPECT_EQ(read_file(f), "second\n");
}

TEST_F(ShellTest, AppendRedirect) {
    std::string f = dir.file("o.txt");
    run("echo one > '" + f + "'");
    run("echo two >> '" + f + "'");
    run("echo three >> '" + f + "'");
    EXPECT_EQ(read_file(f), "one\ntwo\nthree\n");
}

TEST_F(ShellTest, InputRedirect) {
    std::string in = dir.file("in.txt");
    write_file(in, "b\na\nc\n");
    EXPECT_EQ(out_of("sort < '" + in + "'"), "a\nb\nc\n");
}

TEST_F(ShellTest, InputAndOutputRedirectTogether) {
    std::string in = dir.file("in.txt"), out = dir.file("out.txt");
    write_file(in, "zebra\napple\n");
    ASSERT_EQ(run("sort < '" + in + "' > '" + out + "'"), 0);
    EXPECT_EQ(read_file(out), "apple\nzebra\n");
}

TEST_F(ShellTest, MissingInputFileFailsWithStatus1) {
    EXPECT_EQ(run("cat < /no/such/file"), 1);
}

TEST_F(ShellTest, UnwritableOutputFails) {
    EXPECT_EQ(run("echo x > /no/such/dir/file"), 1);
}

TEST_F(ShellTest, BuiltinRedirectionRestoresDescriptors) {
    int before = open_fd_count();
    std::string f = dir.file("pwd.txt");
    run("pwd > '" + f + "'");
    run("echo visible after");                   // stdout must be restored
    EXPECT_EQ(open_fd_count(), before);
    EXPECT_FALSE(read_file(f).empty());
}

// ------------------------------------------------------ Level 4: pipes
TEST_F(ShellTest, SimplePipe) {
    EXPECT_EQ(out_of("echo a b c | wc -w"), "3\n");
}

TEST_F(ShellTest, ThreeStagePipeline) {
    EXPECT_EQ(out_of("printf 'b\\na\\nb\\nc\\na\\n' | sort | uniq"), "a\nb\nc\n");
}

TEST_F(ShellTest, LongPipeline) {
    EXPECT_EQ(out_of("seq 1 100 | grep 5 | grep -v 50 | wc -l"), "18\n");
}

TEST_F(ShellTest, PipelineStatusIsLastCommand) {
    EXPECT_EQ(run("false | true"), 0);
    EXPECT_EQ(run("true | false"), 1);
}

TEST_F(ShellTest, PipelineWithRedirects) {
    std::string in = dir.file("in.txt"), out = dir.file("out.txt");
    write_file(in, "x\ny\nx\n");
    ASSERT_EQ(run("cat < '" + in + "' | grep x | wc -l > '" + out + "'"), 0);
    EXPECT_EQ(read_file(out), "2\n");
}

TEST_F(ShellTest, BuiltinInsidePipeline) {
    EXPECT_EQ(out_of("echo hello | cat"), "hello\n");
    run("echo one");
    run("echo two");
    std::string n = out_of("history | wc -l");
    EXPECT_GE(atoi(n.c_str()), 2);
}

TEST_F(ShellTest, PipeToCommandThatDoesNotReadInput) {
    // writer gets SIGPIPE; the shell must not hang
    EXPECT_NO_FATAL_FAILURE(run("yes | head -n 1 > /dev/null"));
    EXPECT_EQ(sh.last_status, 0);
}

TEST_F(ShellTest, ManyCommandsDoNotLeakDescriptors) {
    int before = open_fd_count();
    for (int i = 0; i < 150; i++) run("echo x | cat > /dev/null");
    for (int i = 0; i < 50; i++) run("echo y > /dev/null");
    EXPECT_EQ(open_fd_count(), before);
}

// ------------------------------------------- Level 2/6: background & jobs
TEST_F(ShellTest, BackgroundJobIsTrackedAndFinishes) {
    ASSERT_EQ(run("sleep 0.3 &"), 0);
    ASSERT_EQ(jobs_count(&sh.jobs), 1);
    Job *j = jobs_find_by_id(&sh.jobs, 1);
    ASSERT_NE(j, nullptr);
    EXPECT_EQ(j->state, JOB_RUNNING);
    wait_job_done(1);
    j = jobs_find_by_id(&sh.jobs, 1);
    ASSERT_NE(j, nullptr);
    EXPECT_EQ(j->state, JOB_DONE);
    EXPECT_EQ(j->status, 0);
}

TEST_F(ShellTest, BackgroundDoesNotBlockShell) {
    auto t0 = time(nullptr);
    run("sleep 2 &");
    EXPECT_LE(time(nullptr) - t0, 1);
    run("kill %1");
    wait_job_done(1);
}

TEST_F(ShellTest, JobsBuiltinListsAndPrunes) {
    run("sleep 0.2 &");
    std::string running = out_of("jobs");
    EXPECT_NE(running.find("[1]+"), std::string::npos);
    EXPECT_NE(running.find("sleep 0.2 &"), std::string::npos);
    wait_job_done(1);
    std::string done = out_of("jobs");
    EXPECT_NE(done.find("Done"), std::string::npos);
    EXPECT_EQ(jobs_count(&sh.jobs), 0);               // pruned after being listed
}

TEST_F(ShellTest, KillJobBySignal) {
    run("sleep 30 &");
    ASSERT_EQ(jobs_count(&sh.jobs), 1);
    EXPECT_EQ(run("kill %1"), 0);
    wait_job_done(1);
    Job *j = jobs_find_by_id(&sh.jobs, 1);
    ASSERT_NE(j, nullptr);
    EXPECT_EQ(j->state, JOB_DONE);
    EXPECT_EQ(j->status, 128 + SIGTERM);
}

TEST_F(ShellTest, KillWithExplicitSignal) {
    run("sleep 30 &");
    EXPECT_EQ(run("kill -KILL %1"), 0);
    wait_job_done(1);
    EXPECT_EQ(jobs_find_by_id(&sh.jobs, 1)->status, 128 + SIGKILL);
}

TEST_F(ShellTest, KillErrors) {
    EXPECT_EQ(run("kill"), 2);
    EXPECT_EQ(run("kill -NOSUCH 1"), 2);
    EXPECT_EQ(run("kill %9"), 1);
    EXPECT_EQ(run("kill abc"), 1);
}

TEST_F(ShellTest, ForegroundBringsBackgroundJob) {
    run("sleep 0.3 &");
    auto t0 = time(nullptr);
    EXPECT_EQ(run("fg %1"), 0);
    EXPECT_GE(time(nullptr) - t0, 0);
    EXPECT_EQ(jobs_count(&sh.jobs), 0);               // removed after completion
}

TEST_F(ShellTest, ForegroundReturnsJobStatus) {
    run("sh -c 'sleep 0.2; exit 9' &");
    EXPECT_EQ(run("fg"), 9);
}

TEST_F(ShellTest, FgBgErrorsWithoutJobs) {
    EXPECT_EQ(run("fg"), 1);
    EXPECT_EQ(run("bg"), 1);
    EXPECT_EQ(run("fg %5"), 1);
}

TEST_F(ShellTest, StoppedJobCanBeResumedWithBg) {
    run("sleep 1 &");
    ASSERT_EQ(run("kill -STOP %1"), 0);
    Job *j = nullptr;
    for (int i = 0; i < 200; i++) {
        jobs_update(&sh.jobs);
        j = jobs_find_by_id(&sh.jobs, 1);
        if (j && j->state == JOB_STOPPED) break;
        usleep(10000);
    }
    ASSERT_NE(j, nullptr);
    EXPECT_EQ(j->state, JOB_STOPPED);
    EXPECT_EQ(run("bg %1"), 0);
    EXPECT_EQ(j->state, JOB_RUNNING);
    wait_job_done(1);
    EXPECT_EQ(jobs_find_by_id(&sh.jobs, 1)->state, JOB_DONE);
}

TEST_F(ShellTest, BackgroundPipelineIsOneJob) {
    run("sleep 0.2 | cat &");
    ASSERT_EQ(jobs_count(&sh.jobs), 1);
    EXPECT_EQ(jobs_find_by_id(&sh.jobs, 1)->npids, 2);
    wait_job_done(1);
}

// ---------------------------------------------------- Level 5: history
TEST_F(ShellTest, HistoryRecordsAndExpands) {
    run("echo first");
    EXPECT_EQ(out_of("!!"), "echo first\nfirst\n");   // expansion is echoed, then run
    EXPECT_EQ(run("!nosuchprefix"), 1);
}

TEST_F(ShellTest, HistoryBuiltinOutputAndClear) {
    run("echo aaa");
    run("echo bbb");
    std::string h = out_of("history");
    EXPECT_NE(h.find("echo aaa"), std::string::npos);
    EXPECT_NE(h.find("echo bbb"), std::string::npos);
    run("history -c");
    EXPECT_EQ(sh.history.count, 0);
    EXPECT_EQ(run("history abc"), 1);
}

TEST_F(ShellTest, HistoryNotRecordedInsideScripts) {
    std::string script = dir.file("s.msh");
    write_file(script, "echo inside1\necho inside2\n");
    run("source '" + script + "'");
    EXPECT_EQ(sh.history.count, 1);                   // only the `source` line itself
}

// ----------------------------------------------------------- source
TEST_F(ShellTest, SourceRunsScript) {
    std::string script = dir.file("s.msh"), out = dir.file("o.txt");
    write_file(script, "# a script\necho one > '" + out + "'\necho two >> '" + out + "'\nexport MS_S=xyz\n");
    EXPECT_EQ(run("source '" + script + "'"), 0);
    EXPECT_EQ(read_file(out), "one\ntwo\n");
    EXPECT_STREQ(getenv("MS_S"), "xyz");
    unsetenv("MS_S");
}

TEST_F(ShellTest, SourceErrors) {
    EXPECT_EQ(run("source"), 2);
    EXPECT_EQ(run("source /no/such/script"), 1);
}

TEST_F(ShellTest, SourceRecursionIsBounded) {
    std::string script = dir.file("loop.msh");
    write_file(script, "source '" + script + "'\n");
    EXPECT_NO_FATAL_FAILURE(run("source '" + script + "'"));
    EXPECT_EQ(sh.script_depth, 0);
}

TEST_F(ShellTest, ShellRunStreamReadsFromFile) {
    std::string script = dir.file("stream.msh"), out = dir.file("o.txt");
    write_file(script, "echo a > '" + out + "'\nexit 5\necho never >> '" + out + "'\n");
    FILE *fp = fopen(script.c_str(), "r");
    ASSERT_NE(fp, nullptr);
    EXPECT_EQ(shell_run_stream(&sh, fp), 5);
    fclose(fp);
    EXPECT_EQ(read_file(out), "a\n");
}

// ------------------------------------------- infrastructure commands
TEST_F(ShellTest, LoganalyzeBuiltin) {
    write_file(dir.file("a.log"), "ERROR x\nINFO y\nWARN z\n");
    write_file(dir.file("b.log"), "ERROR a\nERROR b\n");
    std::string out = out_of("loganalyze -t 2 -p ERROR '" + dir.file("a.log") + "' '" + dir.file("b.log") + "'");
    EXPECT_NE(out.find("TOTAL"), std::string::npos);
    EXPECT_NE(out.find("MATCH"), std::string::npos);
    std::istringstream in(out);
    std::string line, total;
    while (std::getline(in, line)) if (line.rfind("TOTAL", 0) == 0) total = line;
    std::istringstream t(total);
    std::string label; long lines, errs;
    t >> label >> lines >> errs;
    EXPECT_EQ(lines, 5);
    EXPECT_EQ(errs, 3);
}

TEST_F(ShellTest, LoganalyzeUsageAndMissingFile) {
    EXPECT_EQ(run("loganalyze"), 2);
    EXPECT_EQ(run("loganalyze -t 0 x"), 2);
    EXPECT_EQ(run("loganalyze -z x"), 2);
    EXPECT_EQ(run("loganalyze /no/such/file.log > /dev/null"), 1);
}

TEST_F(ShellTest, ServicesStatus) {
    std::string comm = read_file("/proc/self/comm");
    while (!comm.empty() && comm.back() == '\n') comm.pop_back();
    EXPECT_EQ(run("services status '" + comm + "' > /dev/null"), 0);
    EXPECT_EQ(run("services status no-such-service-xyz > /dev/null"), 1);
    EXPECT_EQ(run("services bogus"), 2);
    EXPECT_NE(out_of("services list").find("PID"), std::string::npos);
}

TEST_F(ShellTest, SysinfoPrintsMetrics) {
    std::string s = out_of("sysinfo");
    EXPECT_NE(s.find("Load average"), std::string::npos);
    EXPECT_NE(s.find("Memory"), std::string::npos);
    EXPECT_NE(s.find("Disk"), std::string::npos);
}

TEST_F(ShellTest, MonitorBuiltinStartStatusStop) {
    EXPECT_EQ(run("monitor stop > /dev/null"), 1);            // not running
    EXPECT_EQ(run("monitor start 1 > /dev/null"), 0);
    EXPECT_EQ(run("monitor start 1 > /dev/null"), 1);        // already running
    for (int i = 0; i < 200 && monitor_sample_count(&sh.monitor) == 0; i++) usleep(10000);
    std::string st = out_of("monitor status");
    EXPECT_NE(st.find("running"), std::string::npos);
    EXPECT_NE(st.find("Load average"), std::string::npos);
    EXPECT_EQ(run("monitor stop > /dev/null"), 0);
    EXPECT_NE(out_of("monitor").find("stopped"), std::string::npos);
    EXPECT_EQ(run("monitor start 0"), 2);
    EXPECT_EQ(run("monitor wat"), 2);
}

TEST_F(ShellTest, CleanupBuiltinDryRunAndForce) {
    std::string d = dir.file("tmpdir");
    mkdir(d.c_str(), 0755);
    write_file(d + "/stale.tmp", "data");
    write_file(d + "/fresh.tmp", "data");
    struct timeval tv[2];
    gettimeofday(&tv[0], nullptr);
    tv[0].tv_sec -= 40 * 86400;
    tv[1] = tv[0];
    utimes((d + "/stale.tmp").c_str(), tv);

    std::string dry = out_of("cleanup '" + d + "' 30");
    EXPECT_NE(dry.find("would remove"), std::string::npos);
    EXPECT_TRUE(file_exists(d + "/stale.tmp"));
    out_of("cleanup '" + d + "' 30 --force");
    EXPECT_FALSE(file_exists(d + "/stale.tmp"));
    EXPECT_TRUE(file_exists(d + "/fresh.tmp"));
    EXPECT_EQ(run("cleanup"), 2);
    EXPECT_EQ(run("cleanup /no/such/dir 5"), 1);
}

// ------------------------------------------------------------- audit
TEST_F(ShellTest, AuditTrailRecordsEveryCommand) {
    run("echo audited");
    run("false");
    run("nosuchcmd_zzz");
    std::string log = read_file(sh.audit_path);
    EXPECT_EQ(count_lines(log), 3);
    EXPECT_NE(log.find("|0|echo audited"), std::string::npos);
    EXPECT_NE(log.find("|1|false"), std::string::npos);
    EXPECT_NE(log.find("|127|nosuchcmd_zzz"), std::string::npos);
}

TEST_F(ShellTest, AuditReportBuiltin) {
    run("echo a");
    run("echo b");
    run("false");
    std::string rep = out_of("audit report");
    EXPECT_NE(rep.find("Total commands"), std::string::npos);
    EXPECT_NE(rep.find("echo"), std::string::npos);
    EXPECT_NE(out_of("audit tail 1").find("audit report"), std::string::npos);

    std::string exp = dir.file("report.txt");
    EXPECT_EQ(run("audit export '" + exp + "' > /dev/null"), 0);
    EXPECT_NE(read_file(exp).find("Audit Report"), std::string::npos);
    EXPECT_EQ(run("audit bogus"), 2);
    EXPECT_EQ(run("audit tail zero"), 2);
}

TEST_F(ShellTest, AuditLogContainsPipelinesVerbatim) {
    run("echo x | wc -c");
    EXPECT_NE(read_file(sh.audit_path).find("|0|echo x | wc -c"), std::string::npos);
}

// --------------------------------------------------------------- prompt
TEST(Prompt, PlainAndColor) {
    char b[256];
    prompt_build(b, sizeof b, 0, "root", "srv01", "/var/log", "/root");
    EXPECT_STREQ(b, "root@srv01:/var/log$ ");
    prompt_build(b, sizeof b, 1, "root", "srv01", "/var/log", "/root");
    EXPECT_NE(strstr(b, "\033[1;32mroot@srv01"), nullptr);
}

TEST(Prompt, HomeIsAbbreviated) {
    char b[256];
    prompt_build(b, sizeof b, 0, "u", "h", "/home/u/work", "/home/u");
    EXPECT_STREQ(b, "u@h:~/work$ ");
    prompt_build(b, sizeof b, 0, "u", "h", "/home/u", "/home/u");
    EXPECT_STREQ(b, "u@h:~$ ");
    prompt_build(b, sizeof b, 0, "u", "h", "/home/user2", "/home/u");   // prefix but different dir
    EXPECT_STREQ(b, "u@h:/home/user2$ ");
}

TEST(Builtins, TableIsConsistent) {
    size_t n = 0;
    const Builtin *t = builtin_table(&n);
    ASSERT_GE(n, 15u);
    for (size_t i = 0; i < n; i++) {
        EXPECT_TRUE(builtin_is(t[i].name)) << t[i].name;
        EXPECT_NE(t[i].fn, nullptr);
        EXPECT_GT(strlen(t[i].help), 0u);
    }
    EXPECT_FALSE(builtin_is("ls"));
    EXPECT_FALSE(builtin_is(""));
}

} // namespace
