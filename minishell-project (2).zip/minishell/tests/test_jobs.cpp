#include "test_util.hpp"
#include <signal.h>
#include <sys/wait.h>
#include <set>
#include <vector>

namespace {

// Hand-made wait() statuses
int exited(int code)  { return (code & 0xff) << 8; }
int signaled(int sig) { return sig; }
int stopped(int sig)  { return (sig << 8) | 0x7f; }
const int continued = 0xffff;

class JobsTest : public ::testing::Test {
protected:
    JobTable t;
    void SetUp() override { jobs_init(&t); }
    void TearDown() override { jobs_destroy(&t); }
    Job *add(pid_t pgid, std::initializer_list<pid_t> pids, const char *cmd) {
        std::vector<pid_t> v(pids);
        return jobs_add(&t, pgid, v.data(), (int)v.size(), cmd);
    }
};

TEST_F(JobsTest, AddAssignsIncreasingIds) {
    Job *a = add(100, {100}, "sleep 1 &");
    Job *b = add(200, {200}, "sleep 2 &");
    EXPECT_EQ(a->id, 1);
    EXPECT_EQ(b->id, 2);
    EXPECT_EQ(jobs_count(&t), 2);
    EXPECT_EQ(jobs_last(&t), b);
    EXPECT_STREQ(a->cmd, "sleep 1 &");
    EXPECT_EQ(a->state, JOB_RUNNING);
}

TEST_F(JobsTest, FindById) {
    add(100, {100}, "a");
    Job *b = add(200, {200}, "b");
    EXPECT_EQ(jobs_find_by_id(&t, 2), b);
    EXPECT_EQ(jobs_find_by_id(&t, 9), nullptr);
}

TEST_F(JobsTest, FindByPidInPipeline) {
    Job *j = add(300, {300, 301, 302}, "a | b | c");
    EXPECT_EQ(jobs_find_by_pid(&t, 301), j);
    EXPECT_EQ(jobs_find_by_pid(&t, 999), nullptr);
}

TEST_F(JobsTest, RemoveMiddleKeepsList) {
    Job *a = add(1, {1}, "a");
    Job *b = add(2, {2}, "b");
    Job *c = add(3, {3}, "c");
    jobs_remove(&t, b);
    EXPECT_EQ(jobs_count(&t), 2);
    EXPECT_EQ(jobs_find_by_id(&t, a->id), a);
    EXPECT_EQ(jobs_find_by_id(&t, c->id), c);
    EXPECT_EQ(jobs_find_by_id(&t, 2), nullptr);
}

TEST_F(JobsTest, IdsRestartWhenTableEmptyAndFollowHighest) {
    Job *a = add(1, {1}, "a");
    jobs_remove(&t, a);
    Job *b = add(2, {2}, "b");
    EXPECT_EQ(b->id, 1);                    // empty table: numbering restarts
    Job *c = add(3, {3}, "c");
    Job *d = add(4, {4}, "d");
    jobs_remove(&t, c);
    EXPECT_EQ(d->id, 3);
    EXPECT_EQ(add(5, {5}, "e")->id, 4);     // highest existing + 1
}

TEST_F(JobsTest, ExitMarksDoneWithStatus) {
    Job *j = add(10, {10}, "false &");
    EXPECT_EQ(jobs_mark_pid_status(&t, 10, exited(3)), 1);
    EXPECT_EQ(j->state, JOB_DONE);
    EXPECT_EQ(j->status, 3);
}

TEST_F(JobsTest, SignalDeathGives128PlusSignal) {
    Job *j = add(10, {10}, "sleep 100 &");
    jobs_mark_pid_status(&t, 10, signaled(SIGTERM));
    EXPECT_EQ(j->state, JOB_DONE);
    EXPECT_EQ(j->status, 128 + SIGTERM);
}

TEST_F(JobsTest, PipelineIsDoneOnlyWhenAllProcessesFinished) {
    Job *j = add(20, {20, 21, 22}, "a | b | c");
    jobs_mark_pid_status(&t, 20, exited(0));
    jobs_mark_pid_status(&t, 21, exited(0));
    EXPECT_EQ(j->state, JOB_RUNNING);
    jobs_mark_pid_status(&t, 22, exited(5));
    EXPECT_EQ(j->state, JOB_DONE);
    EXPECT_EQ(j->status, 5);                 // status of the last command wins
}

TEST_F(JobsTest, StopAndContinue) {
    Job *j = add(30, {30, 31}, "a | b");
    jobs_mark_pid_status(&t, 30, stopped(SIGTSTP));
    EXPECT_EQ(j->state, JOB_RUNNING);         // second process still running
    jobs_mark_pid_status(&t, 31, stopped(SIGTSTP));
    EXPECT_EQ(j->state, JOB_STOPPED);
    jobs_mark_pid_status(&t, 30, continued);
    EXPECT_EQ(j->state, JOB_RUNNING);
}

TEST_F(JobsTest, ResumeMarksStoppedProcessesRunning) {
    Job *j = add(40, {40}, "vim");
    jobs_mark_pid_status(&t, 40, stopped(SIGTSTP));
    ASSERT_EQ(j->state, JOB_STOPPED);
    jobs_resume(&t, j);
    EXPECT_EQ(j->state, JOB_RUNNING);
}

TEST_F(JobsTest, UnknownPidIsIgnored) {
    add(50, {50}, "x");
    EXPECT_EQ(jobs_mark_pid_status(&t, 12345, exited(0)), 0);
}

TEST_F(JobsTest, NotifyDonePrintsAndRemovesOnlyFinishedJobs) {
    add(60, {60}, "ok job");
    add(61, {61}, "bad job");
    add(62, {62}, "still running");
    jobs_mark_pid_status(&t, 60, exited(0));
    jobs_mark_pid_status(&t, 61, exited(2));

    char *buf = nullptr; size_t len = 0;
    FILE *f = open_memstream(&buf, &len);
    jobs_notify_done(&t, f);
    fclose(f);
    std::string out(buf);
    free(buf);

    EXPECT_NE(out.find("Done"), std::string::npos);
    EXPECT_NE(out.find("ok job"), std::string::npos);
    EXPECT_NE(out.find("Exit 2"), std::string::npos);
    EXPECT_EQ(out.find("still running"), std::string::npos);
    EXPECT_EQ(jobs_count(&t), 1);
}

TEST_F(JobsTest, NotifyWithNullPrunesSilently) {
    add(70, {70}, "x");
    jobs_mark_pid_status(&t, 70, exited(0));
    jobs_notify_done(&t, nullptr);
    EXPECT_EQ(jobs_count(&t), 0);
}

TEST_F(JobsTest, PrintMarksMostRecentJob) {
    add(80, {80}, "first");
    add(81, {81}, "second");
    char *buf = nullptr; size_t len = 0;
    FILE *f = open_memstream(&buf, &len);
    jobs_print(&t, f);
    fclose(f);
    std::string out(buf);
    free(buf);
    EXPECT_NE(out.find("[2]+"), std::string::npos);
    EXPECT_NE(out.find("[1] "), std::string::npos);
    EXPECT_NE(out.find("Running"), std::string::npos);
}

TEST(WaitStatus, Decode) {
    EXPECT_EQ(decode_wait_status(exited(0)), 0);
    EXPECT_EQ(decode_wait_status(exited(127)), 127);
    EXPECT_EQ(decode_wait_status(signaled(SIGKILL)), 128 + SIGKILL);
}

TEST(JobStateName, Names) {
    EXPECT_STREQ(job_state_name(JOB_RUNNING), "Running");
    EXPECT_STREQ(job_state_name(JOB_STOPPED), "Stopped");
    EXPECT_STREQ(job_state_name(JOB_DONE), "Done");
}

// Thread safety: many threads add jobs concurrently
TEST(JobsThreads, ConcurrentAdds) {
    JobTable t;
    jobs_init(&t);
    const int kThreads = 8, kPer = 100;
    std::vector<pthread_t> th(kThreads);
    struct Arg { JobTable *t; int base; } args[kThreads];
    for (int i = 0; i < kThreads; i++) {
        args[i] = {&t, i * 1000};
        pthread_create(&th[i], nullptr, [](void *a) -> void * {
            Arg *arg = (Arg *)a;
            for (int k = 0; k < kPer; k++) {
                pid_t pid = arg->base + k + 1;
                jobs_add(arg->t, pid, &pid, 1, "x");
            }
            return nullptr;
        }, &args[i]);
    }
    for (auto &x : th) pthread_join(x, nullptr);
    EXPECT_EQ(jobs_count(&t), kThreads * kPer);
    // ids must be unique
    std::set<int> ids;
    for (Job *j = t.head; j; j = j->next) ids.insert(j->id);
    EXPECT_EQ((int)ids.size(), kThreads * kPer);
    jobs_destroy(&t);
}

} // namespace
