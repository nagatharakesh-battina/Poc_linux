# MiniShell - bash-like shell in C for an IT Infrastructure Management Console

A Linux command-line interpreter written in C (GCC, Makefile) that mimics core Bash features
and adds tools for system administrators: health monitoring, service checks, multi-threaded
log analysis, maintenance automation and audit reports.

## Quick start on a Linux server
```bash
tar xzf minishell-project.tar.gz && cd minishell     # tar keeps file permissions
./setup.sh --min        # installs gcc + make only (skip if already installed)
make                    # build   -> bin/minishell
make check              # self-test (needs only bash)
sudo make install       # optional: installs /usr/local/bin/minishell
minishell
```
`make doctor` lists any missing tool. For the full test-suite run `./setup.sh` once.

**If you see `missing separator`, `bad interpreter: /bin/bash^M` or `$'\r': command not found`**
the files have Windows line endings (copied through Windows). Fix once, then rebuild:
```bash
find . -type f \( -name '*.c' -o -name '*.h' -o -name '*.cpp' -o -name '*.hpp' -o -name '*.sh' \
   -o -name '*.msh' -o -name '*.log' -o -name Makefile -o -name '*.md' \) -exec sed -i 's/\r$//' {} +
chmod +x setup.sh tests/integration.sh
```

## Build and run
```bash
./setup.sh               # Ubuntu / Debian / RHEL family (WSL works too)
make                    # builds bin/minishell
./bin/minishell         # interactive
./bin/minishell -c "ls | wc -l"
./bin/minishell scripts/demo.msh
```
State (history, audit log, alerts) lives in `$MINISHELL_HOME` (default `~/.minishell`).

## Features by level
| Level | Feature | Source |
|---|---|---|
| 1 | Custom prompt `user@host:cwd$`, external + built-in commands | `shell.c`, `builtins.c` |
| 2 | `fork` / `execvp` / `waitpid`, background execution `&` | `executor.c` |
| 3 | Redirection `<  >  >>` via `dup2` | `executor.c` |
| 4 | Pipes `a \| b \| c` via `pipe` | `executor.c` |
| 5 | History (linked list, file persistence, `!!` `!N` `!prefix`) | `history.c` |
| 6 | Job control: `jobs fg bg kill`, Ctrl-C / Ctrl-Z, process groups | `jobs.c`, `executor.c` |
| + | Quotes, `$VAR`, `$?`, comments, `;` `&&` `\|\|` | `parser.c`, `shell.c` |

## Infrastructure commands
| Command | Purpose |
|---|---|
| `sysinfo` | CPU load, memory, disk, uptime (+ alerts over threshold) |
| `monitor [status\|start [s]\|stop]` | Background **thread** sampling `/proc`, writes `alerts.log` |
| `services list [filter]` / `services status <name>` | Running processes / is service X up (exit code 0/1) |
| `loganalyze [-t N] [-p pat] files...` | Counts ERROR/WARN/INFO; **thread pool** analyses files in parallel |
| `cleanup <dir> <days> [--force]` | Removes stale `*.tmp *.log *.bak` (dry-run by default) |
| `audit [report\|tail [n]\|export file]` | Every command is recorded; summary report |
| `source <file>` | Run a maintenance script |

## Testing, coverage and static analysis
GoogleTest 1.14 is **bundled** (`tests/third_party/googletest`) and compiled together with the tests by
your own compiler, so there is no dependency on a system gtest and no header/library mismatch
(the `undefined reference to testing::internal::AssertHelper ...` link error).

```bash
make test           # 162 GoogleTest (C++) unit + end-to-end + leak tests
make check          # 20 black-box tests of the real binary (needs only bash)
make coverage       # unit tests + gcov line/branch coverage  -> coverage/summary.txt
make cppcheck       # Cppcheck: --enable=all --inconclusive, must report no findings
make analyze        # GCC -fanalyzer (-Werror): fd/memory leaks, NULL derefs, ...
make leakcheck      # Valgrind full leak check: whole test-suite + the shell running scripts/demo.msh
make asan           # AddressSanitizer + LeakSanitizer + UBSan
make tsan           # ThreadSanitizer (data races)     make helgrind  # Valgrind Helgrind
make misra          # MISRA C:2012 baseline report (Cppcheck addon) -> misra-report.txt
make qa             # build, test, check, cppcheck, analyze, leakcheck, coverage
```
**RHEL / CentOS / Rocky with gcc-toolset:** activate the toolset first so `gcc`/`g++` are the new ones:
`source /opt/rh/gcc-toolset-14/enable` (then `make`). `cppcheck` and `lcov` come from EPEL.

**What the leak tests cover** (`tests/test_leaks.cpp`, run by every `make test`): file descriptors after
repeated pipelines, error paths (exec/redirect/syntax failures) and builtin redirection; threads after
monitor and thread-pool start/stop; zombie processes after background jobs; heap growth of the parser,
history and a long shell session. Valgrind / LeakSanitizer prove that every `malloc` is freed.

**Why some functions are `static` only in production:** helpers used inside a single file
(`parse_loadavg`, `history_get`, ...) are `static` (Cppcheck `staticFunction`). The unit-test build compiles
with `-DMS_UNIT_TEST`, which exposes them to GoogleTest (`include/internal.h`).

## Layout
```
include/  headers (C, usable from C++)      src/    implementation
tests/    gtest *.cpp + integration.sh      scripts/demo.msh   samples/*.log
```
