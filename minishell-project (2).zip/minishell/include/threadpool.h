/* threadpool.h - fixed-size worker pool with a linked-list task queue */
#ifndef THREADPOOL_H
#define THREADPOOL_H

#include <pthread.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*task_fn)(void *arg);

typedef struct Task {
    task_fn fn;
    void   *arg;
    struct Task *next;
} Task;

typedef struct ThreadPool {
    pthread_t *threads;
    int        nthreads;
    Task      *head, *tail;
    int        pending;          /* queued + currently running tasks */
    int        shutdown;
    pthread_mutex_t lock;
    pthread_cond_t  cv_work;
    pthread_cond_t  cv_idle;
} ThreadPool;

ThreadPool *tp_create(int nthreads);
int         tp_submit(ThreadPool *tp, task_fn fn, void *arg);   /* 0 ok */
void        tp_wait(ThreadPool *tp);                            /* until all tasks done */
void        tp_destroy(ThreadPool *tp);

#ifdef __cplusplus
}
#endif
#endif /* THREADPOOL_H */
