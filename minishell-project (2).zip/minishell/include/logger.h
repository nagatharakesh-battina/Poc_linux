/* logger.h - thread-safe append-only file logger (file handling, Level 5) */
#ifndef LOGGER_H
#define LOGGER_H

#include <limits.h>
#include <pthread.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Logger {
    FILE *fp;
    pthread_mutex_t lock;
    char path[PATH_MAX + 32];
} Logger;

int  logger_open(Logger *lg, const char *path);   /* 0 ok, -1 error */
void logger_write(Logger *lg, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void logger_flush(Logger *lg);                    /* push buffered records to disk */
void logger_close(Logger *lg);
void log_timestamp(char *buf, size_t len);        /* "YYYY-MM-DD HH:MM:SS" */

#ifdef __cplusplus
}
#endif
#endif /* LOGGER_H */
