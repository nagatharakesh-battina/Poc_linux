/* shell.h - global shell state and the read-eval loop (Level 1) */
#ifndef SHELL_H
#define SHELL_H

#include "history.h"
#include "jobs.h"
#include "logger.h"
#include "monitor.h"

#include <limits.h>
#include <stdio.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Shell {
    int   last_status;
    int   running;              /* cleared by the exit builtin           */
    int   exit_code;
    int   interactive;          /* stdin is a terminal                   */
    int   script_depth;         /* >0 while executing `source`          */
    int   save_history;
    pid_t pgid;                 /* shell's own process group             */

    History  history;
    JobTable jobs;
    Logger   audit_log;
    Logger   alert_log;
    Monitor  monitor;

    char state_dir[PATH_MAX];
    char history_path[PATH_MAX + 32];
    char audit_path[PATH_MAX + 32];
    char alert_path[PATH_MAX + 32];
} Shell;

/* state_dir may be NULL: $MINISHELL_HOME or $HOME/.minishell is used. */
int  shell_init(Shell *sh, const char *state_dir, int interactive);
void shell_destroy(Shell *sh);

int  shell_run_line(Shell *sh, const char *line);   /* returns exit status */
int  shell_run_stream(Shell *sh, FILE *in);         /* script / piped input */
int  shell_repl(Shell *sh);                         /* interactive loop     */


#ifdef MS_UNIT_TEST
/* Internal helpers: static in production, visible to the unit tests. */
/* Builds the prompt string (Level 1: custom prompt). Pure function. */
void prompt_build(char *buf, size_t len, int color, const char *user,
                  const char *host, const char *cwd, const char *home);
#endif

#ifdef __cplusplus
}
#endif
#endif /* SHELL_H */
