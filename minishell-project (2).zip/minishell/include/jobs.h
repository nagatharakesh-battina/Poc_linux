/* jobs.h - job table (linked list) for background / stopped pipelines (Level 6) */
#ifndef JOBS_H
#define JOBS_H

#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum { JOB_RUNNING = 0, JOB_STOPPED = 1, JOB_DONE = 2 } JobState;
typedef enum { PS_RUNNING = 0, PS_STOPPED = 1, PS_DONE = 2 } ProcState;

typedef struct Job {
    int        id;
    pid_t      pgid;
    pid_t     *pids;
    ProcState *pstate;
    int        npids;
    char      *cmd;
    JobState   state;
    int        status;          /* exit status of the last process in the pipeline */
    struct Job *next;
} Job;

typedef struct JobTable {
    Job *head;
    pthread_mutex_t lock;
} JobTable;

void  jobs_init(JobTable *t);
void  jobs_destroy(JobTable *t);
Job  *jobs_add(JobTable *t, pid_t pgid, const pid_t *pids, int npids, const char *cmd);
Job  *jobs_find_by_id(JobTable *t, int id);
Job  *jobs_find_by_pid(JobTable *t, pid_t pid);
Job  *jobs_last(JobTable *t);
void  jobs_remove(JobTable *t, Job *job);
int   jobs_count(JobTable *t);

/* Applies a waitpid() status to the owning job. Returns 1 if pid was known. */
int   jobs_mark_pid_status(JobTable *t, pid_t pid, int wait_status);
void  jobs_resume(JobTable *t, Job *job);         /* marks live processes running */

/* Non-blocking reap of any finished/stopped children. */
void  jobs_update(JobTable *t);
/* Prints "[n]+ Done ..." for finished jobs and removes them (out may be NULL). */
void  jobs_notify_done(JobTable *t, FILE *out);
void  jobs_print(JobTable *t, FILE *out);


#ifdef MS_UNIT_TEST
/* Internal helpers: static in production, visible to the unit tests. */
const char *job_state_name(JobState s);
int   decode_wait_status(int wait_status);        /* exit code, or 128+signal */
#endif

#ifdef __cplusplus
}
#endif
#endif /* JOBS_H */
