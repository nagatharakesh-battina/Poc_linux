/* internal.h - build-time switches shared by all modules.
 *
 * MS_STATIC : helper functions that are only used inside one source file are
 *             `static` in the production build (MISRA 8.7 / Cppcheck
 *             staticFunction). The unit-test build defines MS_UNIT_TEST, which
 *             removes `static` and enables the prototypes in the headers so
 *             GoogleTest can call them directly.
 * MS_COVERAGE_FLUSH : forked children leave through _exit(), which skips the
 *             gcov exit handler. In the coverage build the counters are written
 *             explicitly so child-side code is counted too. No-op otherwise.
 */
#ifndef INTERNAL_H
#define INTERNAL_H

#ifdef MS_UNIT_TEST
#define MS_STATIC
#else
#define MS_STATIC static
#endif

#ifdef MS_COVERAGE
void __gcov_dump(void);
#define MS_COVERAGE_FLUSH() __gcov_dump()
#else
#define MS_COVERAGE_FLUSH() ((void)0)
#endif

#endif /* INTERNAL_H */
