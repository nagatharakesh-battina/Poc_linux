/* services.h - running process / service inspection through /proc */
#ifndef SERVICES_H
#define SERVICES_H

#include <stdio.h>
#include <sys/types.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    pid_t pid;
    char  name[64];
    char  state;          /* R S D T Z ... */
    long  rss_kb;
} ProcInfo;


/* Returns a heap array (caller frees) and sets *count. */
ProcInfo *proc_list(int *count);

/* Fills pids[] with processes whose name equals `name`; returns how many. */
int  proc_find_by_name(const char *name, pid_t *pids, int max);

void proc_print(const ProcInfo *p, int n, const char *filter, FILE *out);

#ifdef MS_UNIT_TEST
/* Internal helpers: static in production, visible to the unit tests. */
/* Parses the text of /proc/<pid>/status. Returns 0 on success. */
int  parse_proc_status(const char *text, ProcInfo *out);
#endif

#ifdef __cplusplus
}
#endif
#endif /* SERVICES_H */
