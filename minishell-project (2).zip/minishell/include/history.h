/* history.h - command history stored as a singly linked list (Level 5) */
#ifndef HISTORY_H
#define HISTORY_H

#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct HistEntry {
    int   number;                 /* 1-based, monotonically increasing */
    char *line;
    struct HistEntry *next;
} HistEntry;

typedef struct History {
    HistEntry *head;
    HistEntry *tail;
    int count;
    int max;                      /* oldest entries are dropped beyond this */
    int next_number;
} History;

void  history_init(History *h, int max_entries);
void  history_destroy(History *h);
int   history_add(History *h, const char *line);          void  history_clear(History *h);
void  history_print(const History *h, int last_n, FILE *out); /* last_n<=0: all */

/* Expands "!!", "!N" and "!prefix". Returns 0 = nothing to expand,
 * 1 = expanded (*out is a heap string), -1 = event not found. */
int   history_expand(const History *h, const char *line, char **out);

int   history_load(History *h, const char *path);
int   history_save(const History *h, const char *path);

#ifdef MS_UNIT_TEST
/* Internal helpers: static in production, visible to the unit tests. */
/* 1 if stored      */
const char *history_get(const History *h, int number);    /* NULL if missing  */
const char *history_last(const History *h);
#endif

#ifdef __cplusplus
}
#endif
#endif /* HISTORY_H */
