/* monitor.h - background system health monitor thread (reads /proc) */
#ifndef MONITOR_H
#define MONITOR_H

#include "logger.h"
#include <pthread.h>
#include <stdio.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    double load1, load5, load15;
    unsigned long mem_total_kb;
    unsigned long mem_avail_kb;
    double mem_used_pct;
    unsigned long long disk_total;     /* bytes of "/" */
    unsigned long long disk_free;
    double disk_used_pct;
    double uptime_sec;
    int    ncpu;
} SystemMetrics;


int  metrics_collect(SystemMetrics *m);
void metrics_print(const SystemMetrics *m, FILE *out);
/* Writes a description of every breached threshold into buf; returns count. */
int  metrics_check_alerts(const SystemMetrics *m, char *buf, size_t len);

typedef struct Monitor {
    pthread_t       thread;
    pthread_mutex_t lock;
    pthread_cond_t  cond;
    int             running;
    int             stop;
    unsigned        interval_ms;
    SystemMetrics   latest;
    int             has_sample;
    unsigned long   samples;
    unsigned long   alerts;
    Logger         *alert_log;      /* may be NULL */
} Monitor;

void monitor_init(Monitor *m, Logger *alert_log);
int  monitor_start(Monitor *m, unsigned interval_ms);   /* -1 if already running */
void monitor_stop(Monitor *m);
int  monitor_is_running(Monitor *m);
int  monitor_latest(Monitor *m, SystemMetrics *out);    /* 0 if a sample exists  */
unsigned long monitor_sample_count(Monitor *m);
void monitor_destroy(Monitor *m);

#ifdef MS_UNIT_TEST
/* Internal helpers: static in production, visible to the unit tests. */
/* Pure parsers (unit testable) */
int parse_loadavg(const char *text, double out[3]);
int parse_meminfo(const char *text, unsigned long *total_kb, unsigned long *avail_kb);
#endif

#ifdef __cplusplus
}
#endif
#endif /* MONITOR_H */
