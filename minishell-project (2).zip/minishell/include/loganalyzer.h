/* loganalyzer.h - multi-threaded log file analysis */
#ifndef LOGANALYZER_H
#define LOGANALYZER_H

#include <limits.h>
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    char path[PATH_MAX];
    long lines;
    long errors;
    long warnings;
    long infos;
    long matches;        /* lines containing the user supplied pattern */
    int  ok;             /* 0 when the file could not be read          */
} LogStats;


/* Analyze many files with a thread pool. results must hold n entries. */
int  analyze_files_parallel(char **paths, int n, const char *pattern,
                            int nthreads, LogStats *results);

void log_stats_print(const LogStats *r, int n, const char *pattern, FILE *out);

#ifdef MS_UNIT_TEST
/* Internal helpers: static in production, visible to the unit tests. */
/* Analyze one file (case-insensitive ERROR / WARN / INFO counting). */
int  analyze_file(const char *path, const char *pattern, LogStats *st);
void log_stats_total(const LogStats *r, int n, LogStats *total);
#endif

#ifdef __cplusplus
}
#endif
#endif /* LOGANALYZER_H */
