/* parser.h - command line tokenizer and pipeline builder (Level 1/3/4) */
#ifndef PARSER_H
#define PARSER_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* One simple command: argv plus its redirections. Commands form a linked
 * list that represents a pipeline (cmd1 | cmd2 | cmd3). */
typedef struct Command {
    char **argv;              /* NULL terminated                    */
    int    argc;
    char  *infile;            /* < file                             */
    char  *outfile;           /* > file  or  >> file                */
    int    append;            /* 1 for >>                           */
    struct Command *next;
} Command;

typedef struct Pipeline {
    Command *head;
    int      ncmds;
    int      background;      /* trailing '&'                       */
} Pipeline;

typedef enum { PARSE_OK = 0, PARSE_EMPTY = 1, PARSE_ERROR = 2 } ParseStatus;

/* Parse one input line. On PARSE_ERROR a message is written to err.
 * On PARSE_OK the caller must release the result with pipeline_free(). */
ParseStatus parse_line(const char *line, Pipeline *out, char *err, size_t errlen);
void        pipeline_free(Pipeline *p);

/* Value used for $? expansion */
void parser_set_last_status(int status);

#ifdef __cplusplus
}
#endif
#endif /* PARSER_H */
