/* audit.c - audit trail: every executed command is recorded with its status */
#include "audit.h"
#include "utils.h"

#include <stdlib.h>
#include <string.h>

#define MAX_DISTINCT 512

void audit_record(Logger *lg, const char *user, pid_t pid, int status, const char *cmd)
{
    char ts[32];
    char clean[4096];
    size_t i;

    log_timestamp(ts, sizeof ts);
    for (i = 0; i < sizeof clean - 1 && cmd[i] != '\0'; i++)
        clean[i] = (cmd[i] == '\n' || cmd[i] == '\r') ? ' ' : cmd[i];
    clean[i] = '\0';
    logger_write(lg, "%s|%s|%d|%d|%s", ts, user ? user : "unknown", (int)pid, status, clean);
}

/* Splits "a|b|c|d|rest" into fields. Returns 0 on success. */
static int split_record(char *line, char **ts, char **status, char **cmd)
{
    char *user, *pid, *p = line;

    *ts = p;
    if (!(p = strchr(p, '|'))) return -1;
    *p++ = '\0';
    user = p; (void)user;
    if (!(p = strchr(p, '|'))) return -1;
    *p++ = '\0';
    pid = p; (void)pid;
    if (!(p = strchr(p, '|'))) return -1;
    *p++ = '\0';
    *status = p;
    if (!(p = strchr(p, '|'))) return -1;
    *p++ = '\0';
    *cmd = p;
    return 0;
}

static void count_command(CmdCount *tab, int *n, const char *cmd)
{
    char name[64];
    size_t i = 0;

    while (*cmd == ' ') cmd++;
    while (cmd[i] && cmd[i] != ' ' && i < sizeof name - 1) {
        name[i] = cmd[i];
        i++;
    }
    name[i] = '\0';
    if (i == 0) return;

    for (int k = 0; k < *n; k++) {
        if (strcmp(tab[k].name, name) == 0) {
            tab[k].count++;
            return;
        }
    }
    if (*n < MAX_DISTINCT) {
        snprintf(tab[*n].name, sizeof tab[*n].name, "%s", name);
        tab[*n].count = 1;
        (*n)++;
    }
}

int audit_summarize(const char *path, AuditSummary *out)
{
    FILE *fp = fopen(path, "r");
    char *line = NULL;
    size_t cap = 0;
    ssize_t n;
    CmdCount *tab;
    int ntab = 0;

    memset(out, 0, sizeof *out);
    if (!fp)
        return -1;
    tab = xcalloc(MAX_DISTINCT, sizeof *tab);

    while ((n = getline(&line, &cap, fp)) != -1) {
        char *ts, *status, *cmd;
        while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r'))
            line[--n] = '\0';
        if (split_record(line, &ts, &status, &cmd) != 0)
            continue;                                   /* skip malformed lines */
        out->total++;
        if (atoi(status) == 0) out->succeeded++; else out->failed++;
        if (out->first_ts[0] == '\0')
            snprintf(out->first_ts, sizeof out->first_ts, "%s", ts);
        snprintf(out->last_ts, sizeof out->last_ts, "%s", ts);
        count_command(tab, &ntab, cmd);
    }
    free(line);
    fclose(fp);

    /* selection of the top N commands */
    for (int r = 0; r < AUDIT_TOP_N; r++) {
        int best = -1;
        for (int k = 0; k < ntab; k++)
            if (tab[k].count > 0 && (best < 0 || tab[k].count > tab[best].count))
                best = k;
        if (best < 0) break;
        out->top[out->ntop++] = tab[best];
        tab[best].count = 0;
    }
    free(tab);
    return 0;
}

void audit_print_report(const AuditSummary *s, FILE *out)
{
    fprintf(out, "==== MiniShell Audit Report ====\n");
    fprintf(out, "Period          : %s  ->  %s\n",
            s->first_ts[0] ? s->first_ts : "-", s->last_ts[0] ? s->last_ts : "-");
    fprintf(out, "Total commands  : %ld\n", s->total);
    fprintf(out, "Succeeded       : %ld\n", s->succeeded);
    fprintf(out, "Failed          : %ld\n", s->failed);
    if (s->total > 0)
        fprintf(out, "Success rate    : %.1f%%\n", 100.0 * (double)s->succeeded / (double)s->total);
    fprintf(out, "Most used commands:\n");
    for (int i = 0; i < s->ntop; i++)
        fprintf(out, "  %2d. %-20s %ld\n", i + 1, s->top[i].name, s->top[i].count);
    if (s->ntop == 0)
        fprintf(out, "  (none)\n");
}

int audit_tail(const char *path, int n, FILE *out)
{
    FILE *fp = fopen(path, "r");
    char **ring;
    char *line = NULL;
    size_t cap = 0;
    long total = 0;

    if (!fp) return -1;
    if (n <= 0) n = 10;
    ring = xcalloc((size_t)n, sizeof *ring);
    while (getline(&line, &cap, fp) != -1) {
        free(ring[total % n]);
        ring[total % n] = xstrdup(line);
        total++;
    }
    free(line);
    fclose(fp);

    for (long i = total > n ? total - n : 0; i < total; i++)
        fputs(ring[i % n], out);
    for (int i = 0; i < n; i++)
        free(ring[i]);
    free(ring);
    return 0;
}
