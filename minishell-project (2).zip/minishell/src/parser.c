/* parser.c - tokenizer (quotes, escapes, $VAR, comments) and pipeline builder */
#include "parser.h"
#include "utils.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_last_status = 0;

void parser_set_last_status(int status) { g_last_status = status; }

typedef enum { T_WORD, T_PIPE, T_IN, T_OUT, T_APPEND, T_BG } TokType;

typedef struct {
    TokType type;
    char   *text;
} Token;

typedef struct {
    Token *v;
    size_t n, cap;
} TokList;

static void tl_push(TokList *l, TokType t, char *text)
{
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 16;
        l->v = xrealloc(l->v, l->cap * sizeof(Token));
    }
    l->v[l->n].type = t;
    l->v[l->n].text = text;
    l->n++;
}

static void tl_free(TokList *l)
{
    for (size_t i = 0; i < l->n; i++)
        free(l->v[i].text);
    free(l->v);
    l->v = NULL;
    l->n = l->cap = 0;
}

static void set_err(char *err, size_t errlen, const char *msg)
{
    if (err && errlen)
        snprintf(err, errlen, "%s", msg);
}

static int is_op(char c) { return c == '|' || c == '<' || c == '>' || c == '&'; }

/* s[*i] == '$'. Appends the expansion to sb and advances *i. */
static void expand_var(const char *s, size_t *i, StrBuf *sb)
{
    size_t j = *i + 1;

    if (s[j] == '?') {
        char tmp[16];
        snprintf(tmp, sizeof tmp, "%d", g_last_status);
        sb_puts(sb, tmp);
        *i = j + 1;
        return;
    }
    if (isalpha((unsigned char)s[j]) || s[j] == '_') {
        size_t k = j;
        char name[256];
        size_t len;
        const char *v;
        while (isalnum((unsigned char)s[k]) || s[k] == '_')
            k++;
        len = k - j;
        if (len >= sizeof name)
            len = sizeof name - 1;
        memcpy(name, s + j, len);
        name[len] = '\0';
        v = getenv(name);
        if (v)
            sb_puts(sb, v);
        *i = k;
        return;
    }
    sb_putc(sb, '$');
    *i = j;
}

static int tokenize(const char *line, TokList *out, char *err, size_t errlen)
{
    size_t i = 0;

    while (line[i]) {
        char c = line[i];
        if (isspace((unsigned char)c)) { i++; continue; }
        if (c == '#') break;                              /* comment */
        if (c == '|') { tl_push(out, T_PIPE, NULL); i++; continue; }
        if (c == '&') { tl_push(out, T_BG,   NULL); i++; continue; }
        if (c == '<') { tl_push(out, T_IN,   NULL); i++; continue; }
        if (c == '>') {
            if (line[i + 1] == '>') { tl_push(out, T_APPEND, NULL); i += 2; }
            else                    { tl_push(out, T_OUT,    NULL); i++;    }
            continue;
        }

        /* a word */
        StrBuf sb;
        int quoted = 0;
        sb_init(&sb);
        while (line[i] && !isspace((unsigned char)line[i]) && !is_op(line[i])) {
            char d = line[i];
            if (d == '\'') {
                quoted = 1;
                i++;
                while (line[i] && line[i] != '\'')
                    sb_putc(&sb, line[i++]);
                if (!line[i]) {
                    sb_free(&sb);
                    set_err(err, errlen, "unterminated single quote");
                    return -1;
                }
                i++;
            } else if (d == '"') {
                quoted = 1;
                i++;
                while (line[i] && line[i] != '"') {
                    if (line[i] == '\\' &&
                        (line[i + 1] == '"' || line[i + 1] == '\\' || line[i + 1] == '$')) {
                        sb_putc(&sb, line[i + 1]);
                        i += 2;
                    } else if (line[i] == '$') {
                        expand_var(line, &i, &sb);
                    } else {
                        sb_putc(&sb, line[i++]);
                    }
                }
                if (!line[i]) {
                    sb_free(&sb);
                    set_err(err, errlen, "unterminated double quote");
                    return -1;
                }
                i++;
            } else if (d == '\\') {
                if (line[i + 1]) { sb_putc(&sb, line[i + 1]); i += 2; }
                else i++;
                quoted = 1;
            } else if (d == '$') {
                expand_var(line, &i, &sb);
            } else {
                sb_putc(&sb, d);
                i++;
            }
        }
        if (sb.len == 0 && !quoted) {      /* unquoted empty expansion: drop */
            sb_free(&sb);
            continue;
        }
        tl_push(out, T_WORD, sb_take(&sb));
    }
    return 0;
}

static Command *command_new(void)
{
    Command *c = xcalloc(1, sizeof *c);
    c->argv = xcalloc(2, sizeof(char *));   /* room for first arg + NULL */
    return c;
}

static void command_add_arg(Command *c, char *text)
{
    c->argv = xrealloc(c->argv, (size_t)(c->argc + 2) * sizeof(char *));
    c->argv[c->argc++] = text;
    c->argv[c->argc] = NULL;
}

static void command_free(Command *c)
{
    if (!c) return;
    for (int i = 0; i < c->argc; i++)
        free(c->argv[i]);
    free(c->argv);
    free(c->infile);
    free(c->outfile);
    free(c);
}

static void pipeline_append(Pipeline *p, Command *c)
{
    if (!p->head) {
        p->head = c;
    } else {
        Command *t = p->head;
        while (t->next) t = t->next;
        t->next = c;
    }
    p->ncmds++;
}

void pipeline_free(Pipeline *p)
{
    Command *c = p->head;
    while (c) {
        Command *n = c->next;
        command_free(c);
        c = n;
    }
    p->head = NULL;
    p->ncmds = 0;
    p->background = 0;
}

ParseStatus parse_line(const char *line, Pipeline *out, char *err, size_t errlen)
{
    TokList tl = {0};
    Command *cur;

    out->head = NULL;
    out->ncmds = 0;
    out->background = 0;
    if (err && errlen) err[0] = '\0';

    if (tokenize(line, &tl, err, errlen) != 0) {
        tl_free(&tl);
        return PARSE_ERROR;
    }
    if (tl.n == 0) {
        tl_free(&tl);
        return PARSE_EMPTY;
    }

    cur = command_new();
    for (size_t i = 0; i < tl.n; i++) {
        Token *t = &tl.v[i];
        switch (t->type) {
        case T_WORD:
            command_add_arg(cur, t->text);
            t->text = NULL;                       /* ownership moved */
            break;
        case T_PIPE:
            if (cur->argc == 0) {
                set_err(err, errlen, "syntax error near unexpected token '|'");
                goto fail;
            }
            pipeline_append(out, cur);
            cur = command_new();
            break;
        case T_IN:
        case T_OUT:
        case T_APPEND:
            if (i + 1 >= tl.n || tl.v[i + 1].type != T_WORD) {
                set_err(err, errlen, "syntax error: expected file name after redirection");
                goto fail;
            }
            i++;
            if (t->type == T_IN) {
                free(cur->infile);
                cur->infile = tl.v[i].text;
            } else {
                free(cur->outfile);
                cur->outfile = tl.v[i].text;
                cur->append = (t->type == T_APPEND);
            }
            tl.v[i].text = NULL;
            break;
        case T_BG:
            if (i + 1 != tl.n) {
                set_err(err, errlen, "syntax error: '&' must be at the end of the line");
                goto fail;
            }
            out->background = 1;
            break;
        }
    }

    if (cur->argc == 0) {
        set_err(err, errlen, out->ncmds > 0 ? "syntax error: missing command after '|'"
                                            : "syntax error: missing command");
        goto fail;
    }
    pipeline_append(out, cur);
    tl_free(&tl);
    return PARSE_OK;

fail:
    command_free(cur);
    pipeline_free(out);
    tl_free(&tl);
    return PARSE_ERROR;
}
