/* executor.c - process creation, pipes, redirection and job control */
#include "executor.h"
#include "builtins.h"
#include "internal.h"

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

/* Closes fd if it is open and returns -1. Use `fd = close_fd(fd);` when the variable is
 * used again, or `(void)close_fd(fd);` for its last use. */
static int close_fd(int fd)
{
    if (fd >= 0)
        close(fd);
    return -1;
}

/* ---- redirection (dup2) ---------------------------------------------- */

static int apply_redirections(const Command *c)
{
    if (c->infile) {
        int fd = open(c->infile, O_RDONLY);
        if (fd < 0) {
            fprintf(stderr, "minishell: %s: %s\n", c->infile, strerror(errno));
            return -1;
        }
        dup2(fd, STDIN_FILENO);
        close(fd);
    }
    if (c->outfile) {
        int flags = O_WRONLY | O_CREAT | (c->append ? O_APPEND : O_TRUNC);
        int fd = open(c->outfile, flags, 0644);
        if (fd < 0) {
            fprintf(stderr, "minishell: %s: %s\n", c->outfile, strerror(errno));
            return -1;
        }
        dup2(fd, STDOUT_FILENO);
        close(fd);
    }
    return 0;
}

/* Builtin executed in the shell process itself (so `cd`, `export`, `exit`
 * affect the shell). Redirections are applied to saved/restored descriptors. */
static int run_builtin_in_parent(Shell *sh, Command *c)
{
    int status, save_in, save_out;

    fflush(stdout);
    fflush(stderr);
    save_in = dup(STDIN_FILENO);
    save_out = dup(STDOUT_FILENO);
    if (save_in < 0 || save_out < 0) {
        perror("minishell: dup");
        (void)close_fd(save_in);
        (void)close_fd(save_out);
        return 1;
    }

    if (apply_redirections(c) < 0)
        status = 1;
    else
        status = builtin_run(sh, c->argc, c->argv);

    fflush(stdout);
    dup2(save_in, STDIN_FILENO);
    dup2(save_out, STDOUT_FILENO);
    (void)close_fd(save_in);
    (void)close_fd(save_out);
    return status;
}

/* ---- child side ------------------------------------------------------- */

static void reset_signals(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = SIG_DFL;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT,  &sa, NULL);
    sigaction(SIGQUIT, &sa, NULL);
    sigaction(SIGTSTP, &sa, NULL);
    sigaction(SIGTTIN, &sa, NULL);
    sigaction(SIGTTOU, &sa, NULL);
}

__attribute__((noreturn))
static void child_exec(Shell *sh, const Command *c, int in_fd, int out_fd,
                       int unused_read_end, int background)
{
    reset_signals();

    if (in_fd >= 0)  { dup2(in_fd, STDIN_FILENO);   (void)close_fd(in_fd);  }
    if (out_fd >= 0) { dup2(out_fd, STDOUT_FILENO); (void)close_fd(out_fd); }
    (void)close_fd(unused_read_end);                 /* read end of the pipe we write to */

    if (background && in_fd < 0 && c->infile == NULL) {   /* detach from terminal input */
        int nul = open("/dev/null", O_RDONLY);
        if (nul >= 0) { dup2(nul, STDIN_FILENO); (void)close_fd(nul); }
    }

    if (apply_redirections(c) < 0) {
        MS_COVERAGE_FLUSH();
        _exit(1);
    }

    if (builtin_is(c->argv[0])) {                       /* builtin inside a pipeline */
        int st = builtin_run(sh, c->argc, c->argv);
        fflush(stdout);
        MS_COVERAGE_FLUSH();
        _exit(st & 0xff);
    }

    MS_COVERAGE_FLUSH();
    execvp(c->argv[0], c->argv);
    if (errno == ENOENT)
        fprintf(stderr, "minishell: %s: command not found\n", c->argv[0]);
    else
        fprintf(stderr, "minishell: %s: %s\n", c->argv[0], strerror(errno));
    _exit(errno == ENOENT ? 127 : 126);
}

/* ---- foreground wait -------------------------------------------------- */

static int wait_foreground(Shell *sh, Job *job)
{
    int rc;
    int interrupted = 0;

    if (sh->interactive)
        tcsetpgrp(STDIN_FILENO, job->pgid);

    while (job->state == JOB_RUNNING) {
        int st;
        pid_t p = waitpid(-job->pgid, &st, WUNTRACED);
        if (p < 0) {
            if (errno == EINTR) continue;
            for (int i = 0; i < job->npids; i++)          /* ECHILD: nothing left */
                job->pstate[i] = PS_DONE;
            job->state = JOB_DONE;
            break;
        }
        if (WIFSIGNALED(st) && WTERMSIG(st) == SIGINT)
            interrupted = 1;
        jobs_mark_pid_status(&sh->jobs, p, st);
    }

    if (sh->interactive)
        tcsetpgrp(STDIN_FILENO, sh->pgid);

    if (job->state == JOB_STOPPED) {
        fprintf(stderr, "\n[%d]+  Stopped                 %s\n", job->id, job->cmd);
        return 128 + SIGTSTP;
    }
    rc = job->status;
    if (interrupted)
        fputc('\n', stderr);
    jobs_remove(&sh->jobs, job);
    return rc;
}

int executor_foreground_job(Shell *sh, Job *job)
{
    jobs_resume(&sh->jobs, job);
    if (kill(-job->pgid, SIGCONT) < 0 && errno != ESRCH)
        perror("minishell: kill");
    return wait_foreground(sh, job);
}

/* ---- pipeline --------------------------------------------------------- */

int execute_pipeline(Shell *sh, Pipeline *p, const char *cmdline)
{
    Command *c;
    pid_t *pids;
    int npids = 0, prev_read = -1, failed = 0;
    pid_t pgid = 0;
    Job *job;
    int status;

    /* A single builtin runs in the shell process. */
    if (p->ncmds == 1 && !p->background && builtin_is(p->head->argv[0]))
        return run_builtin_in_parent(sh, p->head);

    fflush(stdout);
    fflush(stderr);
    pids = calloc((size_t)p->ncmds, sizeof(pid_t));
    if (!pids) { perror("minishell: calloc"); return 1; }

    for (c = p->head; c != NULL && !failed; c = c->next) {
        int pp[2];
        int read_end = -1;                  /* read end of the pipe to the next stage  */
        int write_end = -1;                 /* write end of that pipe                  */
        pid_t pid;

        if (c->next != NULL) {
            if (pipe(pp) < 0) {
                perror("minishell: pipe");
                failed = 1;
                break;
            }
            read_end = pp[0];
            write_end = pp[1];
        }
        pid = fork();
        if (pid < 0) {
            perror("minishell: fork");
            (void)close_fd(read_end);
            (void)close_fd(write_end);
            failed = 1;
            break;
        }
        if (pid == 0) {
            setpgid(0, pgid);                         /* pgid==0 -> new group */
            child_exec(sh, c, prev_read, write_end, read_end, p->background);   /* never returns */
        }
        /* parent: hand the new read end to the next iteration, close the rest */
        if (pgid == 0) pgid = pid;
        setpgid(pid, pgid);                           /* avoid race with child */
        pids[npids++] = pid;
        prev_read = close_fd(prev_read);
        (void)close_fd(write_end);                    /* parent never uses the write end */
        prev_read = read_end;                         /* ownership moves to prev_read */
    }
    (void)close_fd(prev_read);                        /* last read end (or leftover on failure) */

    if (npids == 0) {
        free(pids);
        return 1;
    }

    job = jobs_add(&sh->jobs, pgid, pids, npids, cmdline);
    free(pids);

    if (p->background) {
        fprintf(stderr, "[%d] %d\n", job->id, (int)pgid);
        return 0;
    }
    status = wait_foreground(sh, job);
    return failed ? 1 : status;
}
