/* services.c - lightweight "ps"-like scanner for service monitoring */
#include "internal.h"
#include "services.h"
#include "utils.h"

#include <ctype.h>
#include <dirent.h>
#include <stdlib.h>
#include <string.h>

MS_STATIC int parse_proc_status(const char *text, ProcInfo *out)
{
    const char *p;
    int got_name = 0;

    memset(out, 0, sizeof *out);
    out->state = '?';
    if ((p = strstr(text, "Name:"))) {
        p += 5;
        while (*p == ' ' || *p == '\t') p++;
        size_t i = 0;
        while (p[i] && p[i] != '\n' && i < sizeof out->name - 1) {
            out->name[i] = p[i];
            i++;
        }
        out->name[i] = '\0';
        got_name = i > 0;
    }
    if ((p = strstr(text, "\nState:"))) {
        p += 7;
        while (*p == ' ' || *p == '\t') p++;
        out->state = *p ? *p : '?';
    }
    if ((p = strstr(text, "\nVmRSS:")))
        sscanf(p + 7, "%ld", &out->rss_kb);
    if ((p = strstr(text, "\nPid:")))
        out->pid = (pid_t)atoi(p + 5);
    return got_name ? 0 : -1;
}

static int read_status(pid_t pid, ProcInfo *out)
{
    char path[64], buf[4096];
    FILE *fp;
    size_t n;

    snprintf(path, sizeof path, "/proc/%d/status", (int)pid);
    fp = fopen(path, "r");
    if (!fp) return -1;
    n = fread(buf, 1, sizeof buf - 1, fp);
    buf[n] = '\0';
    fclose(fp);
    return parse_proc_status(buf, out);
}

ProcInfo *proc_list(int *count)
{
    DIR *d = opendir("/proc");
    const struct dirent *de;
    ProcInfo *arr = NULL;
    int n = 0, cap = 0;

    *count = 0;
    if (!d) return NULL;
    while ((de = readdir(d))) {
        ProcInfo pi;
        if (!isdigit((unsigned char)de->d_name[0])) continue;
        if (read_status((pid_t)atoi(de->d_name), &pi) != 0) continue;
        if (n == cap) {
            cap = cap ? cap * 2 : 128;
            arr = xrealloc(arr, (size_t)cap * sizeof *arr);
        }
        arr[n++] = pi;
    }
    closedir(d);
    *count = n;
    return arr;
}

int proc_find_by_name(const char *name, pid_t *pids, int max)
{
    int n, found = 0;
    ProcInfo *all = proc_list(&n);

    for (int i = 0; i < n && found < max; i++)
        if (strcmp(all[i].name, name) == 0)
            pids[found++] = all[i].pid;
    free(all);
    return found;
}

void proc_print(const ProcInfo *p, int n, const char *filter, FILE *out)
{
    int shown = 0;
    fprintf(out, "%7s  %-5s %10s  %s\n", "PID", "STATE", "RSS(KB)", "NAME");
    for (int i = 0; i < n; i++) {
        if (filter && *filter && !strstr(p[i].name, filter)) continue;
        fprintf(out, "%7d  %-5c %10ld  %s\n", (int)p[i].pid, p[i].state, p[i].rss_kb, p[i].name);
        shown++;
    }
    fprintf(out, "(%d processes)\n", shown);
}
