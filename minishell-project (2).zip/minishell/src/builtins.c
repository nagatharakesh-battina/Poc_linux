/* builtins.c - shell builtins and the infrastructure management commands */
#include "builtins.h"
#include "audit.h"
#include "executor.h"
#include "loganalyzer.h"
#include "maintenance.h"
#include "monitor.h"
#include "services.h"
#include "utils.h"

#include <errno.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

extern char **environ;

/* ---- core builtins ------------------------------------------------------ */

static int bi_cd(Shell *sh, int argc, char **argv)
{
    char old[PATH_MAX], cur[PATH_MAX];
    const char *target;
    int dash = 0;
    (void)sh;

    if (argc > 2) {
        fprintf(stderr, "cd: too many arguments\n");
        return 1;
    }
    if (argc == 1) {
        target = getenv("HOME");
        if (!target) { fprintf(stderr, "cd: HOME not set\n"); return 1; }
    } else if (strcmp(argv[1], "-") == 0) {
        target = getenv("OLDPWD");
        if (!target) { fprintf(stderr, "cd: OLDPWD not set\n"); return 1; }
        dash = 1;
    } else {
        target = argv[1];
    }
    if (!getcwd(old, sizeof old)) old[0] = '\0';
    if (chdir(target) != 0) {
        fprintf(stderr, "cd: %s: %s\n", target, strerror(errno));
        return 1;
    }
    if (old[0]) setenv("OLDPWD", old, 1);
    if (getcwd(cur, sizeof cur)) {
        setenv("PWD", cur, 1);
        if (dash) printf("%s\n", cur);
    }
    return 0;
}

static int bi_pwd(Shell *sh, int argc, char **argv)
{
    char cwd[PATH_MAX];
    (void)sh; (void)argc; (void)argv;
    if (!getcwd(cwd, sizeof cwd)) {
        perror("pwd");
        return 1;
    }
    printf("%s\n", cwd);
    return 0;
}

static int bi_exit(Shell *sh, int argc, char **argv)
{
    long code = sh->last_status;
    if (argc > 1 && parse_long(argv[1], &code) != 0) {
        fprintf(stderr, "exit: %s: numeric argument required\n", argv[1]);
        code = 2;
    }
    sh->exit_code = (int)(code & 0xff);
    sh->running = 0;
    return sh->exit_code;
}

static int bi_echo(Shell *sh, int argc, char **argv)
{
    int i = 1, newline = 1;
    (void)sh;
    if (argc > 1 && strcmp(argv[1], "-n") == 0) { newline = 0; i = 2; }
    for (; i < argc; i++) {
        fputs(argv[i], stdout);
        if (i + 1 < argc) fputc(' ', stdout);
    }
    if (newline) fputc('\n', stdout);
    return 0;
}

static int bi_export(Shell *sh, int argc, char **argv)
{
    (void)sh;
    if (argc == 1) {
        for (char **e = environ; *e; e++)
            printf("export %s\n", *e);
        return 0;
    }
    for (int i = 1; i < argc; i++) {
        char *eq = strchr(argv[i], '=');
        if (!eq || eq == argv[i]) continue;
        *eq = '\0';
        if (setenv(argv[i], eq + 1, 1) != 0)
            fprintf(stderr, "export: %s: %s\n", argv[i], strerror(errno));
        *eq = '=';
    }
    return 0;
}

static int bi_unset(Shell *sh, int argc, char **argv)
{
    (void)sh;
    for (int i = 1; i < argc; i++)
        unsetenv(argv[i]);
    return 0;
}

static int bi_history(Shell *sh, int argc, char **argv)
{
    long n = 0;
    if (argc > 1 && strcmp(argv[1], "-c") == 0) {
        history_clear(&sh->history);
        return 0;
    }
    if (argc > 1 && parse_long(argv[1], &n) != 0) {
        fprintf(stderr, "history: %s: numeric argument required\n", argv[1]);
        return 1;
    }
    history_print(&sh->history, (int)n, stdout);
    return 0;
}

/* ---- job control -------------------------------------------------------- */

static Job *job_from_spec(Shell *sh, const char *spec)
{
    long id;
    if (!spec)
        return jobs_last(&sh->jobs);
    if (*spec == '%') spec++;
    if (parse_long(spec, &id) != 0)
        return NULL;
    return jobs_find_by_id(&sh->jobs, (int)id);
}

static int bi_jobs(Shell *sh, int argc, char **argv)
{
    (void)argc; (void)argv;
    jobs_update(&sh->jobs);
    jobs_print(&sh->jobs, stdout);
    jobs_notify_done(&sh->jobs, NULL);          /* prune finished jobs */
    return 0;
}

static int bi_fg(Shell *sh, int argc, char **argv)
{
    Job *j;
    jobs_update(&sh->jobs);
    j = job_from_spec(sh, argc > 1 ? argv[1] : NULL);
    if (!j) {
        fprintf(stderr, "fg: no such job\n");
        return 1;
    }
    fprintf(stderr, "%s\n", j->cmd);
    return executor_foreground_job(sh, j);
}

static int bi_bg(Shell *sh, int argc, char **argv)
{
    Job *j;
    jobs_update(&sh->jobs);
    j = job_from_spec(sh, argc > 1 ? argv[1] : NULL);
    if (!j) {
        fprintf(stderr, "bg: no such job\n");
        return 1;
    }
    jobs_resume(&sh->jobs, j);
    if (kill(-j->pgid, SIGCONT) < 0) {
        perror("bg");
        return 1;
    }
    fprintf(stderr, "[%d]+ %s &\n", j->id, j->cmd);
    return 0;
}

static int signal_from_name(const char *s)
{
    static const struct { const char *n; int v; } tab[] = {
        {"HUP", SIGHUP}, {"INT", SIGINT}, {"QUIT", SIGQUIT}, {"KILL", SIGKILL},
        {"USR1", SIGUSR1}, {"USR2", SIGUSR2}, {"TERM", SIGTERM}, {"CONT", SIGCONT},
        {"STOP", SIGSTOP}, {"TSTP", SIGTSTP},
    };
    long v;
    if (str_starts_with(s, "SIG")) s += 3;
    if (parse_long(s, &v) == 0 && v > 0 && v < 65) return (int)v;
    for (size_t i = 0; i < sizeof tab / sizeof tab[0]; i++)
        if (strcmp(tab[i].n, s) == 0) return tab[i].v;
    return -1;
}

static int bi_kill(Shell *sh, int argc, char **argv)
{
    int sig = SIGTERM, first = 1, rc = 0;

    if (argc < 2) {
        fprintf(stderr, "usage: kill [-SIGNAL] <pid|%%job> ...\n");
        return 2;
    }
    if (argv[1][0] == '-' && argv[1][1]) {
        sig = signal_from_name(argv[1] + 1);
        if (sig < 0) {
            fprintf(stderr, "kill: %s: invalid signal\n", argv[1] + 1);
            return 2;
        }
        first = 2;
    }
    for (int i = first; i < argc; i++) {
        if (argv[i][0] == '%') {
            const Job *j = job_from_spec(sh, argv[i]);
            if (!j) { fprintf(stderr, "kill: %s: no such job\n", argv[i]); rc = 1; continue; }
            if (kill(-j->pgid, sig) < 0) { perror("kill"); rc = 1; }
        } else {
            long pid;
            if (parse_long(argv[i], &pid) != 0 || pid <= 0) {
                fprintf(stderr, "kill: %s: invalid pid\n", argv[i]);
                rc = 1;
                continue;
            }
            if (kill((pid_t)pid, sig) < 0) { perror("kill"); rc = 1; }
        }
    }
    return rc;
}

static int bi_source(Shell *sh, int argc, char **argv)
{
    FILE *fp;
    int rc;
    if (argc != 2) {
        fprintf(stderr, "usage: source <file>\n");
        return 2;
    }
    if (sh->script_depth >= 16) {
        fprintf(stderr, "source: nesting too deep\n");
        return 1;
    }
    fp = fopen(argv[1], "r");
    if (!fp) {
        fprintf(stderr, "source: %s: %s\n", argv[1], strerror(errno));
        return 1;
    }
    sh->script_depth++;
    rc = shell_run_stream(sh, fp);
    sh->script_depth--;
    fclose(fp);
    return rc;
}

/* ---- infrastructure management ------------------------------------------ */

static int bi_sysinfo(Shell *sh, int argc, char **argv)
{
    SystemMetrics m;
    char alerts[256];
    (void)sh; (void)argc; (void)argv;
    metrics_collect(&m);
    metrics_print(&m, stdout);
    if (metrics_check_alerts(&m, alerts, sizeof alerts) > 0)
        printf("ALERT       : %s\n", alerts);
    return 0;
}

static int bi_monitor(Shell *sh, int argc, char **argv)
{
    const char *sub = argc > 1 ? argv[1] : "status";
    Monitor *m = &sh->monitor;

    if (strcmp(sub, "start") == 0) {
        long sec = 5;
        if (argc > 2 && (parse_long(argv[2], &sec) != 0 || sec < 1)) {
            fprintf(stderr, "monitor: interval must be a positive number of seconds\n");
            return 2;
        }
        if (monitor_start(m, (unsigned)sec * 1000) != 0) {
            fprintf(stderr, "monitor: already running\n");
            return 1;
        }
        printf("monitor started (every %ld s, alerts -> %s)\n", sec, sh->alert_path);
        return 0;
    }
    if (strcmp(sub, "stop") == 0) {
        if (!monitor_is_running(m)) {
            fprintf(stderr, "monitor: not running\n");
            return 1;
        }
        monitor_stop(m);
        printf("monitor stopped\n");
        return 0;
    }
    if (strcmp(sub, "status") == 0) {
        SystemMetrics sm;
        printf("monitor: %s, samples=%lu\n", monitor_is_running(m) ? "running" : "stopped",
               monitor_sample_count(m));
        if (monitor_latest(m, &sm) == 0)
            metrics_print(&sm, stdout);
        return 0;
    }
    fprintf(stderr, "usage: monitor [status|start [seconds]|stop]\n");
    return 2;
}

static int bi_services(Shell *sh, int argc, char **argv)
{
    const char *sub = argc > 1 ? argv[1] : "list";
    (void)sh;

    if (strcmp(sub, "list") == 0) {
        int n;
        ProcInfo *p = proc_list(&n);
        if (!p) { fprintf(stderr, "services: cannot read /proc\n"); return 1; }
        proc_print(p, n, argc > 2 ? argv[2] : NULL, stdout);
        free(p);
        return 0;
    }
    if (strcmp(sub, "status") == 0 && argc > 2) {
        pid_t pids[32];
        int n = proc_find_by_name(argv[2], pids, 32);
        if (n == 0) {
            printf("%s: not running\n", argv[2]);
            return 1;
        }
        printf("%s: running (%d process%s):", argv[2], n, n == 1 ? "" : "es");
        for (int i = 0; i < n; i++) printf(" %d", (int)pids[i]);
        putchar('\n');
        return 0;
    }
    fprintf(stderr, "usage: services [list [filter]] | services status <name>\n");
    return 2;
}

static int bi_loganalyze(Shell *sh, int argc, char **argv)
{
    const char *pattern = NULL;
    long threads = 4;
    int i = 1, n;
    LogStats *res;
    (void)sh;

    for (; i < argc && argv[i][0] == '-'; i++) {
        if (strcmp(argv[i], "-t") == 0 && i + 1 < argc) {
            if (parse_long(argv[++i], &threads) != 0 || threads < 1 || threads > 64) {
                fprintf(stderr, "loganalyze: invalid thread count\n");
                return 2;
            }
        } else if (strcmp(argv[i], "-p") == 0 && i + 1 < argc) {
            pattern = argv[++i];
        } else {
            fprintf(stderr, "usage: loganalyze [-t threads] [-p pattern] file...\n");
            return 2;
        }
    }
    n = argc - i;
    if (n <= 0) {
        fprintf(stderr, "usage: loganalyze [-t threads] [-p pattern] file...\n");
        return 2;
    }
    res = xcalloc((size_t)n, sizeof *res);
    for (int k = 0; k < n; k++)                     /* so unreadable files keep their name */
        snprintf(res[k].path, sizeof res[k].path, "%s", argv[i + k]);
    if (analyze_files_parallel(argv + i, n, pattern, (int)threads, res) != 0) {
        fprintf(stderr, "loganalyze: cannot start worker threads\n");
        free(res);
        return 1;
    }
    log_stats_print(res, n, pattern, stdout);
    {
        int bad = 0;
        for (int k = 0; k < n; k++) if (!res[k].ok) bad = 1;
        free(res);
        return bad;
    }
}

static int bi_cleanup(Shell *sh, int argc, char **argv)
{
    long days;
    int force = 0;
    CleanupResult r;
    (void)sh;

    if (argc < 3 || parse_long(argv[2], &days) != 0 || days < 0) {
        fprintf(stderr, "usage: cleanup <dir> <days> [--force]\n");
        return 2;
    }
    if (argc > 3 && strcmp(argv[3], "--force") == 0) force = 1;
    if (cleanup_dir(argv[1], (int)days, force, stdout, &r) != 0) {
        fprintf(stderr, "cleanup: %s: %s\n", argv[1], strerror(errno));
        return 1;
    }
    printf("%ld file(s) examined, %ld older than %ld day(s) (%lld bytes), %ld removed%s\n",
           r.examined, r.matched, days, r.bytes, r.removed, force ? "" : "  [dry-run, use --force]");
    return 0;
}

static int bi_audit(Shell *sh, int argc, char **argv)
{
    const char *sub = argc > 1 ? argv[1] : "report";

    logger_flush(&sh->audit_log);               /* make sure every record is readable */
    if (strcmp(sub, "report") == 0) {
        AuditSummary s;
        if (audit_summarize(sh->audit_path, &s) != 0) {
            fprintf(stderr, "audit: cannot read %s\n", sh->audit_path);
            return 1;
        }
        audit_print_report(&s, stdout);
        return 0;
    }
    if (strcmp(sub, "tail") == 0) {
        long n = 10;
        if (argc > 2 && (parse_long(argv[2], &n) != 0 || n < 1)) {
            fprintf(stderr, "audit: invalid line count\n");
            return 2;
        }
        return audit_tail(sh->audit_path, (int)n, stdout) == 0 ? 0 : 1;
    }
    if (strcmp(sub, "export") == 0 && argc > 2) {
        AuditSummary s;
        FILE *fp;
        if (audit_summarize(sh->audit_path, &s) != 0) {
            fprintf(stderr, "audit: cannot read %s\n", sh->audit_path);
            return 1;
        }
        fp = fopen(argv[2], "w");
        if (!fp) {
            fprintf(stderr, "audit: %s: %s\n", argv[2], strerror(errno));
            return 1;
        }
        audit_print_report(&s, fp);
        fclose(fp);
        printf("report written to %s\n", argv[2]);
        return 0;
    }
    fprintf(stderr, "usage: audit [report | tail [n] | export <file>]\n");
    return 2;
}

static int bi_help(Shell *sh, int argc, char **argv);

/* ---- table -------------------------------------------------------------- */

static const Builtin g_builtins[] = {
    {"cd",         bi_cd,         "cd [dir | -]",                           "Change the current directory"},
    {"pwd",        bi_pwd,        "pwd",                                    "Print the working directory"},
    {"echo",       bi_echo,       "echo [-n] [text...]",                    "Print arguments"},
    {"export",     bi_export,     "export [NAME=value ...]",                "Set environment variables"},
    {"unset",      bi_unset,      "unset NAME ...",                         "Remove environment variables"},
    {"history",    bi_history,    "history [N | -c]",                       "Show or clear command history (!! !N !prefix)"},
    {"jobs",       bi_jobs,       "jobs",                                   "List background and stopped jobs"},
    {"fg",         bi_fg,         "fg [%job]",                              "Bring a job to the foreground"},
    {"bg",         bi_bg,         "bg [%job]",                              "Resume a stopped job in the background"},
    {"kill",       bi_kill,       "kill [-SIGNAL] <pid|%job> ...",          "Send a signal to a process or job"},
    {"source",     bi_source,     "source <file>",                          "Run commands from a script file"},
    {"sysinfo",    bi_sysinfo,    "sysinfo",                                "CPU load, memory, disk and uptime"},
    {"monitor",    bi_monitor,    "monitor [status|start [sec]|stop]",      "Control the background health monitor thread"},
    {"services",   bi_services,   "services [list [filter]|status <name>]", "List running processes / check a service"},
    {"loganalyze", bi_loganalyze, "loganalyze [-t N] [-p pat] file...",     "Analyze log files using worker threads"},
    {"cleanup",    bi_cleanup,    "cleanup <dir> <days> [--force]",         "Remove stale *.tmp/*.log/*.bak files (dry-run by default)"},
    {"audit",      bi_audit,      "audit [report|tail [n]|export <file>]",  "Audit trail summary and reports"},
    {"help",       bi_help,       "help [command]",                         "Show help"},
    {"exit",       bi_exit,       "exit [code]",                            "Leave the shell"},
};

#define NBUILTINS (sizeof g_builtins / sizeof g_builtins[0])

const Builtin *builtin_table(size_t *count)
{
    if (count) *count = NBUILTINS;
    return g_builtins;
}

static int bi_help(Shell *sh, int argc, char **argv)
{
    size_t n;
    const Builtin *tab = builtin_table(&n);
    (void)sh;
    if (argc > 1) {
        for (size_t i = 0; i < n; i++) {
            if (strcmp(tab[i].name, argv[1]) == 0) {
                printf("usage: %s\n  %s\n", tab[i].usage, tab[i].help);
                return 0;
            }
        }
        fprintf(stderr, "help: no help for '%s'\n", argv[1]);
        return 1;
    }
    printf("MiniShell built-in commands:\n");
    for (size_t i = 0; i < n; i++)
        printf("  %-38s %s\n", tab[i].usage, tab[i].help);
    printf("\nOperators: |  <  >  >>  &    Quotes: '...' \"...\"    Variables: $VAR $?\n");
    return 0;
}

int builtin_is(const char *name)
{
    size_t n;
    const Builtin *tab = builtin_table(&n);
    for (size_t i = 0; i < n; i++)
        if (strcmp(tab[i].name, name) == 0)
            return 1;
    return 0;
}

int builtin_run(Shell *sh, int argc, char **argv)
{
    size_t n;
    const Builtin *tab = builtin_table(&n);
    for (size_t i = 0; i < n; i++)
        if (strcmp(tab[i].name, argv[0]) == 0)
            return tab[i].fn(sh, argc, argv);
    return 127;
}
