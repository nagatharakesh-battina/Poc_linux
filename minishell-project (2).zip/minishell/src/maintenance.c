/* maintenance.c - safe cleanup of stale temporary / log files */
#include "maintenance.h"
#include "utils.h"

#include <dirent.h>
#include <limits.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static int has_safe_suffix(const char *name)
{
    return str_ends_with(name, ".tmp") || str_ends_with(name, ".log") ||
           str_ends_with(name, ".bak");
}

int cleanup_dir(const char *dir, int days, int force, FILE *out, CleanupResult *res)
{
    DIR *d = opendir(dir);
    const struct dirent *de;
    time_t cutoff = time(NULL) - (time_t)days * 86400;

    memset(res, 0, sizeof *res);
    if (!d) return -1;

    while ((de = readdir(d))) {
        char path[PATH_MAX];
        struct stat st;

        if (!has_safe_suffix(de->d_name)) continue;
        snprintf(path, sizeof path, "%s/%s", dir, de->d_name);
        if (lstat(path, &st) != 0 || !S_ISREG(st.st_mode)) continue;
        res->examined++;
        if (st.st_mtime >= cutoff) continue;

        res->matched++;
        res->bytes += st.st_size;
        if (force) {
            if (unlink(path) == 0) {
                res->removed++;
                fprintf(out, "removed  %s\n", path);
            } else {
                fprintf(out, "failed   %s\n", path);
            }
        } else {
            fprintf(out, "would remove  %s\n", path);
        }
    }
    closedir(d);
    return 0;
}
