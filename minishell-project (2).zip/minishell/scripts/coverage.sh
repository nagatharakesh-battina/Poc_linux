#!/usr/bin/env bash
# Summarises gcov results.  usage: coverage.sh <dir with .gcda/.gcno> <output dir>
set -u
OBJDIR="${1:-build/cov}"; OUT="${2:-coverage}"
command -v gcov >/dev/null || { echo "gcov not found (part of gcc)"; exit 1; }
mkdir -p "$OUT"
ROOT="$(pwd)"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

( cd "$TMP" && gcov -b -c -o "$ROOT/$OBJDIR" "$ROOT"/"$OBJDIR"/*.gcda >"$TMP/gcov.txt" 2>/dev/null )

awk -v root="$ROOT/" '
/^Creating/ { keep=0 }
/^File / { gsub(/\x27/,"",$2); f=$2; sub(root,"",f); keep = (f ~ /^src\//) }
keep && /^Lines executed:/    { split($2,a,"[:% ]"); pct=substr($2,10); sub(/%.*/,"",pct); n=$4; l[f]=pct; ln[f]=n }
keep && /^Branches executed:/ { bp=substr($2,10); sub(/%.*/,"",bp); b[f]=bp }
END {
  printf "%-24s %8s %9s %10s\n","FILE","LINES","COVERED","BRANCHES"
  tot=0; cov=0
  for (f in l) { c=int(l[f]*ln[f]/100+0.5); tot+=ln[f]; cov+=c
     printf "%-24s %8d %8.1f%% %9s%%\n", f, ln[f], l[f], (f in b)?b[f]:"-" }
  printf "%-24s %8d %8.1f%%\n","TOTAL (src/*.c)",tot,(tot? 100*cov/tot:0)
}' "$TMP/gcov.txt" | { read -r head; echo "$head"; sort; } | tee "$OUT/summary.txt"

if command -v lcov >/dev/null && command -v genhtml >/dev/null; then
  lcov -q -c -d "$OBJDIR" -o "$OUT/lcov.info" --rc branch_coverage=1 2>/dev/null &&
  lcov -q -e "$OUT/lcov.info" "$ROOT/src/*" -o "$OUT/lcov.info" 2>/dev/null &&
  genhtml -q "$OUT/lcov.info" -o "$OUT/html" && echo "HTML report: $OUT/html/index.html"
else
  echo "(install lcov for an HTML report; summary saved in $OUT/summary.txt)"
fi
