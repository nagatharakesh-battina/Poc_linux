#!/usr/bin/env bash
# Installs build / QA tools on common Linux distributions.
#   ./setup.sh          gcc, g++, make, valgrind, cppcheck, lcov   (GoogleTest is bundled in tests/third_party)
#   ./setup.sh --min    only gcc + make: enough to build and run the shell
set -e
SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
MIN=0; [ "${1:-}" = "--min" ] && MIN=1

if command -v apt-get >/dev/null; then
    $SUDO apt-get update
    PK="build-essential make"
    [ $MIN -eq 0 ] && PK="$PK g++ valgrind cppcheck lcov"
    $SUDO apt-get install -y $PK
elif command -v dnf >/dev/null || command -v yum >/dev/null; then
    PM=$(command -v dnf || command -v yum)
    PK="gcc make"
    [ $MIN -eq 0 ] && PK="$PK gcc-c++ valgrind"
    $SUDO $PM install -y $PK
    if [ $MIN -eq 0 ]; then       # these two live in EPEL on RHEL/CentOS/Rocky/Alma
        $SUDO $PM install -y cppcheck lcov 2>/dev/null || \
            echo "NOTE: cppcheck / lcov not in enabled repos. Enable EPEL (dnf install epel-release) and rerun."
    fi
elif command -v zypper >/dev/null; then
    PK="gcc make"
    [ $MIN -eq 0 ] && PK="$PK gcc-c++ valgrind cppcheck lcov"
    $SUDO zypper install -y $PK
else
    echo "Unknown package manager. Install manually: gcc g++ make (optional: valgrind cppcheck lcov)"; exit 1
fi
echo; make doctor
